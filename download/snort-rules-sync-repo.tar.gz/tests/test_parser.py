"""Тесты парсера правил Snort/Suricata."""

from snort_rules_sync.parser import normalize_rule, parse_rules, scan_rule_texts

from conftest import R_A1, R_A2, R_A3


def test_simple_rules():
    text = f"# comment\n\n{R_A1}\n{R_A2}\n"
    res = parse_rules(text, origin="t")
    assert len(res.rules) == 2
    assert res.warnings == []
    assert res.rules[0].sid == 2000001
    assert res.rules[0].rev == 3
    assert res.rules[0].msg == "SNRT Test alpha"
    assert res.rules[0].action == "alert"


def test_normalization_whitespace_and_trailing_comment():
    r1 = 'alert tcp any any -> any any (msg:"x"; content:"a b"; sid:1; rev:1;)   # trailing comment'
    r2 = 'alert  tcp  any  any  ->  any  any  (msg:"x";  content:"a b";  sid:1;  rev:1;)   \n'
    res = parse_rules(r1 + "\n" + r2)
    assert len(res.rules) == 2
    # нормализованные тексты совпадают -> одинаковый digest
    assert res.rules[0].digest == res.rules[1].digest
    # пробел ВНУТРИ content сохранён
    assert 'content:"a b"' in res.rules[0].normalized
    # хвостовой комментарий отброшен
    assert "#" not in res.rules[0].raw


def test_escaped_quotes_in_content():
    rule = r'alert tcp any any -> any any (msg:"quote \" inside"; content:"he said \"hi\""; sid:42; rev:1;)'
    res = parse_rules(rule)
    assert len(res.rules) == 1
    assert res.rules[0].sid == 42
    assert res.rules[0].msg == 'quote \\" inside'


def test_multiline_rule():
    text = (
        'alert tcp any any -> any any (\n'
        '    msg:"multi line";\n'
        '    content:"abc";\n'
        '    sid:777; rev:1;)\n'
    )
    res = parse_rules(text)
    assert len(res.rules) == 1
    assert res.rules[0].sid == 777
    # нормализация делает многострочное правило эквивалентным однострочному
    single = parse_rules('alert tcp any any -> any any (msg:"multi line"; content:"abc"; sid:777; rev:1;)')
    assert res.rules[0].digest == single.rules[0].digest


def test_crlf_and_blank_lines():
    text = f"{R_A1}\r\n\r\n{R_A2}\r\n"
    res = parse_rules(text)
    assert len(res.rules) == 2
    assert res.warnings == []


def test_unparsed_lines_reported():
    text = 'include other.rules\n' + R_A1 + '\nrandom garbage line\n'
    res = parse_rules(text)
    assert len(res.rules) == 1
    assert len(res.warnings) == 2
    assert "include" in res.warnings[0]


def test_unterminated_rule_warning():
    text = 'alert tcp any any -> any any (msg:"never closed"; sid:5; rev:1;\n'
    texts, warnings = scan_rule_texts(text)
    assert texts == []
    assert len(warnings) == 1


def test_rule_without_sid():
    res = parse_rules('alert tcp any any -> any any (msg:"no sid here"; content:"x";)')
    assert len(res.rules) == 1
    assert res.rules[0].sid is None


def test_sid_regex_not_confused_by_nested():
    rule = 'alert tcp any any -> any any (msg:"sid:111 is in msg"; content:"x"; sid:222; rev:4;)'
    res = parse_rules(rule)
    assert res.rules[0].sid == 222
    assert res.rules[0].rev == 4
    assert res.rules[0].msg == "sid:111 is in msg"


def test_normalize_idempotent():
    rule = 'alert tcp  any any ->  any any (msg:"m"; content:"a b c"; sid:1; rev:1;)'
    n1 = normalize_rule(rule)
    assert normalize_rule(n1) == n1
