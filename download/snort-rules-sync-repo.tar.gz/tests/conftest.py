"""Общие фикстуры тестов: генераторы архивов правил и фейковые HTTP-серверы."""

from __future__ import annotations

import io
import re
import tarfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest

# ---------------------------------------------------------------------------
# образцы правил
# ---------------------------------------------------------------------------

R_A1 = 'alert tcp $HOME_NET any -> $EXTERNAL_NET 80 (msg:"SNRT Test alpha"; flow:to_server,established; content:"alpha"; sid:2000001; rev:3;)'
R_A2 = 'alert tcp $EXTERNAL_NET 80 -> $HOME_NET any (msg:"SNRT Test beta"; flow:from_server; content:"beta"; sid:2000002; rev:1;)'
R_A3 = 'alert http $HOME_NET any -> $EXTERNAL_NET any (msg:"SNRT Test gamma"; http_uri; content:"/gamma"; sid:2000003; rev:2;)'
R_COL = 'drop tcp $HOME_NET any -> 10.0.0.1 445 (msg:"SNRT Collision"; content:"boom"; sid:3000007; rev:5;)'

# Правила, «уже живущие» в Clear NDR
C_SAME = 'alert tcp $HOME_NET any -> $EXTERNAL_NET 80 (msg:"SNRT Test alpha"; flow:to_server,established; content:"alpha"; sid:2000001; rev:3;)'
C_OLDER = 'alert tcp $HOME_NET any -> $EXTERNAL_NET 80 (msg:"SNRT Test alpha"; flow:to_server; content:"alpha"; sid:2000001; rev:2;)'
C_OTHER = 'alert udp any any -> 8.8.8.8 53 (msg:"PT Existing rule"; content:"x"; sid:2000002; rev:9;)'

COMMUNITY_RULES_TEXT = f"""# community rules sample
{R_A1}
{R_A2}
{R_COL}
"""

SNAPSHOT_RULES = {
    "rules/snort3-community.rules": f"""# snort3 community
{R_A1}
{R_A2}
{R_A3}
""",
    "rules/app-detect.rules": f"""# app-detect
{R_COL}
""",
    "rules/snort3-deleted.rules": '# deleted\n',
    "etc/snort.lua": "# lua config, not rules\n",
}


def make_tar(path: Path, files: dict[str, str]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(path, "w:gz") as tar:
        for name, text in files.items():
            data = text.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
    return path


def make_scirius_export(rules_text: str) -> bytes:
    """Тарбол в формате экспорта Scirius: один файл scirius.rules."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        data = rules_text.encode("utf-8")
        info = tarfile.TarInfo("scirius.rules")
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Фейковый snort.org
# ---------------------------------------------------------------------------


class FakeSnortServer:
    """Имитация www.snort.org: страница downloads, community-архив, reg-rules."""

    def __init__(self, oinkcode: str = "deadbeef01"):
        self.oinkcode = oinkcode
        self.snapshot_version = "31700"
        self.community_failures_left = 0  # сколько ответов 500 выдать перед успехом
        self.requests: list[str] = []
        self.community_tar = make_tar(
            _tmp_file("community-rules.tar.gz"),
            {"community.rules": COMMUNITY_RULES_TEXT, "AUTHORS": "talos\n"},
        ).read_bytes()
        self.snapshot_tar = make_tar(_tmp_file("snapshot.tar.gz"), SNAPSHOT_RULES).read_bytes()

        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):  # тишина
                pass

            def _send(self, code: int, body: bytes, ctype: str = "text/html") -> None:
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                path = urlparse(self.path).path
                outer.requests.append(self.path)
                if path == "/downloads":
                    html = " ".join(
                        f"snortrules-snapshot-{v}.tar.gz"
                        for v in ("29200", "31300", outer.snapshot_version)
                    )
                    self._send(200, html.encode())
                elif path == "/downloads/community/community-rules.tar.gz":
                    if outer.community_failures_left > 0:
                        outer.community_failures_left -= 1
                        self._send(500, b"boom")
                        return
                    self._send(200, outer.community_tar, "application/gzip")
                elif re.fullmatch(rf"/reg-rules/snortrules-snapshot-\d+\.tar\.gz/{outer.oinkcode}", path):
                    self._send(200, outer.snapshot_tar, "application/gzip")
                elif re.fullmatch(r"/reg-rules/snortrules-snapshot-\d+\.tar\.gz/.*", path):
                    self._send(403, b"invalid oinkcode")
                else:
                    self._send(404, b"nope")

        self._srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._srv.serve_forever, daemon=True)

    @property
    def base(self) -> str:
        host, port = self._srv.server_address
        return f"http://{host}:{port}"

    def start(self):
        self._thread.start()
        return self

    def stop(self):
        self._srv.shutdown()


def _tmp_file(name: str) -> Path:
    d = Path("/tmp/snort-rules-sync-test")
    d.mkdir(exist_ok=True)
    return d / name


# ---------------------------------------------------------------------------
# Фейковый Scirius (Clear NDR)
# ---------------------------------------------------------------------------


class FakeSciriusServer:
    """Достаточно DRF-подобный Scirius: token-аутентификация, сессия+CSRF,
    REST эндпоинты и функциональные view export/update."""

    TOKEN = "tok-abc123"
    USER = "scirius"
    PASSWORD = "s3cret"

    def __init__(self, existing_rules_text: str):
        self.existing_rules_text = existing_rules_text
        self.rulesets = [{"pk": 1, "name": "default", "sources": [], "categories": []}]
        self.sources: list[dict] = []
        self.categories: list[dict] = []
        self.next_pk = 10
        self.uploaded: list[tuple[str, bytes]] = []  # (filename, bytes)
        self.updates_triggered: list[int] = []
        self.sessions: set[str] = set()
        self.csrf_by_session: dict[str, str] = {}
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code: int, body: bytes, ctype: str = "application/json", cookies: list[str] | None = None):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                for c in cookies or []:
                    self.send_header("Set-Cookie", c)
                self.end_headers()
                self.wfile.write(body)

            def _json(self, code: int, obj):
                import json

                self._send(code, json.dumps(obj).encode())

            def _cookies(self) -> dict[str, str]:
                raw = self.headers.get("Cookie", "")
                out = {}
                for part in raw.split(";"):
                    if "=" in part:
                        k, v = part.split("=", 1)
                        out[k.strip()] = v.strip()
                return out

            def _authorized_token(self) -> bool:
                return self.headers.get("Authorization") == f"Token {outer.TOKEN}"

            def _has_session(self) -> bool:
                return "sessionid" in self._cookies()

            def _check_csrf(self, body: bytes) -> bool:
                cookie_csrf = self._cookies().get("csrftoken", "")
                header_csrf = self.headers.get("X-CSRFToken", "")
                if header_csrf and header_csrf == cookie_csrf:
                    return True
                m = re.search(rb'name="csrfmiddlewaretoken"\s+value="([^"]+)"', body)
                return bool(m and m.group(1).decode() == cookie_csrf)

            def do_GET(self):
                parsed = urlparse(self.path)
                path = parsed.path
                qs = parse_qs(parsed.query)
                if path == "/rest/rules/ruleset/":
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    return self._json(200, {"count": len(outer.rulesets), "next": None,
                                            "previous": None, "results": outer.rulesets})
                if re.fullmatch(r"/rest/rules/ruleset/\d+/", path):
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    pk = int(path.strip("/").split("/")[-1])
                    for r in outer.rulesets:
                        if r["pk"] == pk:
                            return self._json(200, r)
                    return self._send(404, b"{}")
                if path == "/rest/rules/source/":
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    search = qs.get("search", [""])[0]
                    results = [s for s in outer.sources if search in s["name"]]
                    return self._json(200, {"count": len(results), "next": None,
                                            "previous": None, "results": results})
                if path == "/rest/rules/category/":
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    source = int(qs.get("source", ["0"])[0])
                    results = [c for c in outer.categories if c["source"] == source]
                    return self._json(200, {"count": len(results), "next": None,
                                            "previous": None, "results": results})
                if path == "/rest/rules/rule/":
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    category = int(qs.get("category", ["0"])[0])
                    page = int(qs.get("page", ["1"])[0])
                    rules = [r for r in outer.categories if r["source"] == category]
                    # rule rows хранятся в rules_by_category
                    rows = outer.rules_by_category.get(category, [])
                    per = 2
                    chunk = rows[(page - 1) * per : page * per]
                    nxt = f"/rest/rules/rule/?category={category}&page={page + 1}" \
                        if page * per < len(rows) else None
                    return self._json(200, {"count": len(rows), "next": nxt,
                                            "previous": None, "results": chunk})
                if path == "/accounts/login/":
                    csrf = "csrf-token-1"
                    body = (
                        '<form method="post">'
                        '<input type="hidden" name="csrfmiddlewaretoken" value="%s">'
                        '<input name="username"><input name="password"></form>' % csrf
                    ).encode()
                    return self._send(200, body, "text/html",
                                      cookies=[f"csrftoken={csrf}; Path=/"])
                return self._send(404, b"{}")

            def do_POST(self):
                length = int(self.headers.get("Content-Length", "0") or 0)
                body = self.rfile.read(length) if length else b""
                parsed = urlparse(self.path)
                path = parsed.path

                if path == "/accounts/login/":
                    form = parse_qs(body.decode())
                    cookie_csrf = self._cookies().get("csrftoken", "")
                    if (
                        form.get("username", [""])[0] == outer.USER
                        and form.get("password", [""])[0] == outer.PASSWORD
                        and form.get("csrfmiddlewaretoken", [""])[0] == cookie_csrf
                    ):
                        sid = "session-xyz"
                        outer.sessions.add(sid)
                        outer.csrf_by_session[sid] = cookie_csrf
                        return self._send(200, b"ok", "text/html",
                                          cookies=[f"sessionid={sid}; Path=/",
                                                   f"csrftoken={cookie_csrf}; Path=/"])
                        # 302 на / эмулируем 200 + cookie
                    return self._send(400, b"bad login", "text/html")

                if re.fullmatch(r"/rest/rules/source/\d+/upload/", path):
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    m = re.search(rb'name="file"; filename="([^"]+)"\r?\n', body)
                    if not m:
                        return self._send(400, b'{"upload":["no file"]}')
                    fname = m.group(1).decode()
                    # грубое извлечение бинарной части multipart
                    parts = body.split(b"\r\n\r\n", 1)
                    payload = parts[1].rsplit(b"\r\n--", 1)[0] if len(parts) > 1 else b""
                    outer.uploaded.append((fname, payload))
                    return self._json(200, {"upload": "ok"})

                if re.fullmatch(r"/rules/ruleset/\d+/export/", path):
                    if not self._has_session():
                        return self._send(302, b"redirect to login", "text/html")
                    if not self._check_csrf(body):
                        return self._send(403, b"CSRF failed", "text/html")
                    return self._send(200, make_scirius_export(outer.existing_rules_text),
                                      "application/gzip")

                if re.fullmatch(r"/rules/ruleset/\d+/update/", path):
                    if not self._has_session():
                        return self._send(302, b"redirect to login", "text/html")
                    if not self._check_csrf(body):
                        return self._send(403, b"CSRF failed", "text/html")
                    pk = int(re.search(r"/rules/ruleset/(\d+)/update/", path).group(1))
                    outer.updates_triggered.append(pk)
                    return self._json(200, {"status": True})

                if re.fullmatch(r"/rules/source/\d+/activate/\d+/", path):
                    if not self._has_session():
                        return self._send(302, b"redirect to login", "text/html")
                    return self._json(200, True)

                if path == "/rest/rules/source/":
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    form = outer._parse_body(body)
                    outer.next_pk += 1
                    src = {"pk": outer.next_pk, "name": form.get("name", "?"),
                           "method": form.get("method", "local"),
                           "datatype": form.get("datatype", "sigs")}
                    outer.sources.append(src)
                    return self._json(201, src)

                return self._send(404, b"{}")

            def do_PATCH(self):
                length = int(self.headers.get("Content-Length", "0") or 0)
                body = self.rfile.read(length) if length else b""
                path = urlparse(self.path).path
                if re.fullmatch(r"/rest/rules/ruleset/\d+/", path):
                    if not self._authorized_token():
                        return self._send(401, b'{"detail":"invalid token"}')
                    import json

                    pk = int(path.strip("/").split("/")[-1])
                    data = json.loads(body)
                    for r in outer.rulesets:
                        if r["pk"] == pk:
                            r["sources"] = data.get("sources", r["sources"])
                            r["categories"] = data.get("categories", r["categories"])
                            return self._json(200, r)
                    return self._send(404, b"{}")
                return self._send(404, b"{}")

        outer.rules_by_category: dict[int, list] = {}

        def _parse_body(body: bytes) -> dict:
            """JSON или urlencoded тело POST -> плоский словарь."""
            try:
                import json

                data = json.loads(body.decode("utf-8"))
                if isinstance(data, dict):
                    return dict(data)
            except Exception:
                pass
            flat = {}
            for k, v in parse_qs(body.decode("utf-8", errors="replace")).items():
                flat[k] = v[0] if isinstance(v, list) else v
            return flat

        outer._parse_body = _parse_body

        self._srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._srv.serve_forever, daemon=True)

    def add_rules_via_rest(self, category_pk: int, source_pk: int, rules_text: str):
        """Готовит данные для pull_rules_via_rest: правила с версиями."""
        rows = []
        for i, line in enumerate(l for l in rules_text.splitlines() if l.strip()):
            sid_m = re.search(r"sid:(\d+)", line)
            rows.append({
                "pk": i + 1,
                "sid": int(sid_m.group(1)) if sid_m else i + 1,
                "msg": line,
                "versions": [{"version": 1, "rev": 1, "content": line, "state": 1,
                              "commented_in_source": False}],
            })
        self.rules_by_category[category_pk] = rows
        self.categories.append({"pk": category_pk, "name": f"cat{category_pk}", "source": source_pk})

    @property
    def base(self) -> str:
        host, port = self._srv.server_address
        return f"http://{host}:{port}"

    def start(self):
        self._thread.start()
        return self

    def stop(self):
        self._srv.shutdown()


# ---------------------------------------------------------------------------
# фикстуры pytest
# ---------------------------------------------------------------------------


@pytest.fixture()
def snort_server():
    srv = FakeSnortServer().start()
    yield srv
    srv.stop()


@pytest.fixture()
def scirius_server():
    srv = FakeSciriusServer(
        existing_rules_text="\n".join([C_SAME, C_OTHER]) + "\n"
    ).start()
    yield srv
    srv.stop()


@pytest.fixture()
def workdir(tmp_path) -> Path:
    d = tmp_path / "workdir"
    d.mkdir()
    return d
