"""Запись выходных артефактов: финальный .rules, tar.gz для Scirius, манифест, отчёт."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import tarfile
from dataclasses import asdict
from io import BytesIO
from pathlib import Path

from . import __version__
from .pipeline import BuildResult

HEADER_TMPL = """\
# =====================================================================
# Сгенерировано snort-rules-sync {version} ({ts})
# Источники (по приоритету): {sources}
# Правил в файле: {count}
# Входных правил: {total_input}
#
# Этот файл предназначен для импорта в Clear NDR (Scirius) как источник
# "Signatures files in tar archive". Пересечения SID устранены,
# перенумерованные правила помечены комментарием.
# =====================================================================
"""


def _rule_comment(rule) -> list[str]:
    lines = []
    if "renumbered" in rule.flags:
        lines.append(f"# sid перенумерован: {rule.sid} -> {rule.final_sid} ({rule.origin})")
    if "upgrade" in rule.flags:
        lines.append(f"# обновление существующей сигнатуры (более новая rev), sid {rule.final_sid}")
    return lines


def render_rules_file(result: BuildResult) -> str:
    ts = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = HEADER_TMPL.format(
        version=__version__,
        ts=ts,
        sources=", ".join(result.sources_order),
        count=result.stats.total_output,
        total_input=result.stats.total_input,
    )
    sections: list[str] = [header]
    current_origin = None
    for rule in result.rules:
        if rule.origin != current_origin:
            current_origin = rule.origin
            n = sum(1 for r in result.rules if r.origin == current_origin)
            sections.append(f"\n# ---- Источник: {current_origin} ({n} правил) ----\n")
        for c in _rule_comment(rule):
            sections.append(c)
        text = rule.raw if rule.final_sid == rule.sid else _replace_sid(rule.raw, rule.final_sid)
        sections.append(text)
        sections.append("")
    return "\n".join(sections).rstrip() + "\n"


def _replace_sid(rule_text: str, new_sid: int | None) -> str:
    """Заменяет значение sid: в тексте правила (первое вхождение опции sid)."""
    import re

    if new_sid is None:
        return rule_text
    return re.sub(r"(\bsid\s*:\s*)\d+", lambda m: f"{m.group(1)}{new_sid}", rule_text, count=1)


def build_tarball(rules_text: str, source_name: str, out_path: Path) -> Path:
    """Tar.gz в формате источника Scirius: все файлы под rules/."""
    buf = BytesIO(rules_text.encode("utf-8"))
    inner_name = f"rules/{source_name}.rules"
    with tarfile.open(out_path, "w:gz") as tar:
        info = tarfile.TarInfo(name=inner_name)
        info.size = buf.getbuffer().nbytes
        info.mtime = int(dt.datetime.now().timestamp())
        tar.addfile(info, buf)
    return out_path


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def write_manifest(result: BuildResult, out_dir: Path, extra: dict | None = None) -> Path:
    manifest = {
        "generator": f"snort-rules-sync {__version__}",
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "sources_order": result.sources_order,
        "per_source_total": result.stats.per_source_total,
        "total_input": result.stats.total_input,
        "total_output": result.stats.total_output,
        "dropped_identical": result.stats.dropped_identical,
        "dropped_superseded": result.stats.dropped_superseded,
        "dropped_collisions": result.stats.dropped_collisions,
        "renumbered": result.stats.renumbered,
        "upgraded": result.stats.upgraded,
    }
    if extra:
        manifest.update(extra)
    p = out_dir / "manifest.json"
    p.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return p


def write_report(result: BuildResult, out_dir: Path, notes: list[str] | None = None) -> Path:
    s = result.stats
    lines: list[str] = []
    lines.append("# Отчёт snort-rules-sync")
    lines.append("")
    lines.append(f"* Дата: {dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"* Входных правил: **{s.total_input}**")
    lines.append(f"* Итоговых правил: **{s.total_output}**")
    lines.append("")
    lines.append("## По источникам")
    lines.append("")
    lines.append("| Источник | Правил на входе |")
    lines.append("|---|---|")
    for name in result.sources_order:
        lines.append(f"| {name} | {s.per_source_total.get(name, 0)} |")
    lines.append("")
    lines.append("## Дедупликация и конфликты")
    lines.append("")
    lines.append(f"* Удалено идентичных дублей: {len(s.dropped_identical)}")
    lines.append(f"* Удалено устаревших версий (меньший rev): {len(s.dropped_superseded)}")
    lines.append(f"* Перенумеровано SID: {len(s.renumbered)}")
    lines.append(f"* Обновлено до новой rev (тот же SID): {len(s.upgraded)}")
    lines.append(f"* Отброшено из-за конфликтов: {len(s.dropped_collisions)}")
    if notes:
        lines.append("")
        lines.append("## Заметки")
        lines.append("")
        for n in notes:
            lines.append(f"* {n}")
    if s.renumbered:
        lines.append("")
        lines.append("## Карта перенумерации SID")
        lines.append("")
        lines.append("| Старый SID | Новый SID | msg | Источник | Причина |")
        lines.append("|---|---|---|---|---|")
        for r in s.renumbered:
            lines.append(
                f"| {r['old_sid']} | {r['new_sid']} | {r['msg'][:60]} | {r['source']} | {r['reason']} |"
            )
    if s.dropped_collisions:
        lines.append("")
        lines.append("## Отброшенные конфликты")
        lines.append("")
        lines.append("| SID | msg | Источник | Причина |")
        lines.append("|---|---|---|---|")
        for r in s.dropped_collisions:
            lines.append(f"| {r['sid']} | {r['msg'][:60]} | {r['source']} | {r['reason']} |")
    p = out_dir / "report.md"
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return p
