"""Клиент Clear NDR (Scirius) для snort-rules-sync.

Реализовано по коду Scirius (StamusNetworks/scirius) и его REST API:

* /rest/* — DRF API, авторизация заголовком ``Authorization: Token <token>``;
* функциональные view (экспорт ruleset'а и команда "Update ruleset") требуют
  веб-сессию: логин POST /accounts/login/ с CSRF-токеном.

Ключевые факты, из-за которых вся эта утилита существует:
  * Rule.sid в Scirius — глобальный первичный ключ. Импорт источника, в котором
    есть SID, уже занят другим источником, приводит к
    DuplicateSidException("The source contains conflicting SID") либо к
    перетаскиванию правила в новый источник;
  * источник типа "Signatures files in tar archive" (datatype=sigs, method=local)
    загружается POST /rest/rules/source/<pk>/upload/ (multipart, поле file);
  * в архиве все файлы должны лежать в каталоге rules/;
  * привязка источника к ruleset'у — PATCH /rest/rules/ruleset/<pk>/ с полями
    sources и categories (или функциональный view activate);
  * применение правил к сенсору — POST /rules/ruleset/<pk>/update/ (сессия).
"""

from __future__ import annotations

import io
import logging
import re
import tarfile
from pathlib import Path

import requests

from .config import ClearNDRConfig

log = logging.getLogger("cleardmr")


class SciriusError(Exception):
    pass


class SciriusAuthError(SciriusError):
    pass


class SciriusClient:
    def __init__(self, cfg: ClearNDRConfig):
        if not cfg.url:
            raise SciriusError("cleardmr.url не задан")
        self.cfg = cfg
        self.base = cfg.url.rstrip("/")
        self._token_session = requests.Session()
        self._token_session.verify = cfg.verify_tls
        self._web_session: requests.Session | None = None

    # ================= низкий уровень =================

    def rest(self, method: str, path: str, **kwargs) -> requests.Response:
        """Запрос к DRF API с token-аутентификацией."""
        if not self.cfg.token:
            raise SciriusAuthError(
                "Нужен cleardmr.token (User Settings -> Edit Token в Scirius) "
                "или переменная окружения CLEARDMR_TOKEN"
            )
        url = f"{self.base}{path}"
        headers = kwargs.pop("headers", {})
        headers["Authorization"] = f"Token {self.cfg.token}"
        headers.setdefault("Content-Type", "application/json")
        resp = self._token_session.request(method, url, headers=headers, timeout=60, **kwargs)
        if resp.status_code in (401, 403):
            raise SciriusAuthError(f"Отказ доступа к {path}: HTTP {resp.status_code} {resp.text[:200]}")
        if resp.status_code >= 400:
            raise SciriusError(f"{method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}")
        return resp

    def web_session(self) -> requests.Session:
        """Сессия с логином/паролем для функциональных view (экспорт, update ruleset)."""
        if self._web_session is not None:
            return self._web_session
        if not (self.cfg.username and self.cfg.password):
            raise SciriusAuthError(
                "Для этой операции нужны cleardmr.username и cleardmr.password "
                "(или переменная CLEARDMR_PASSWORD): функциональные view Scirius "
                "не принимают token-аутентификацию"
            )
        s = requests.Session()
        s.verify = self.cfg.verify_tls
        login_url = f"{self.base}/accounts/login/"
        page = s.get(login_url, timeout=60)
        page.raise_for_status()
        csrf = s.cookies.get("csrftoken")
        if not csrf:
            m = re.search(r'name="csrfmiddlewaretoken"\s+value="([^"]+)"', page.text)
            csrf = m.group(1) if m else None
        if not csrf:
            raise SciriusAuthError("Не удалось получить CSRF-токен со страницы логина")
        resp = s.post(
            login_url,
            data={
                "username": self.cfg.username,
                "password": self.cfg.password,
                "csrfmiddlewaretoken": csrf,
                "next": "/",
            },
            headers={"Referer": login_url},
            timeout=60,
        )
        if "sessionid" not in s.cookies and "/accounts/login" in resp.url:
            raise SciriusAuthError("Логин в Scirius не удался (неверный логин/пароль?)")
        self._web_session = s
        log.info("Веб-сессия Scirius установлена (пользователь %s)", self.cfg.username)
        return s

    def _web_post(self, path: str, **kwargs) -> requests.Response:
        s = self.web_session()
        csrf = s.cookies.get("csrftoken", "")
        headers = kwargs.pop("headers", {})
        if csrf:
            headers.setdefault("X-CSRFToken", csrf)
        headers.setdefault("Referer", f"{self.base}/")
        url = f"{self.base}{path}"
        resp = s.post(url, headers=headers, timeout=120, **kwargs)
        if resp.status_code >= 400:
            raise SciriusError(f"POST {path} -> HTTP {resp.status_code}: {resp.text[:300]}")
        return resp

    # ================= поиск объектов =================

    def find_ruleset(self, name: str) -> dict | None:
        resp = self.rest("GET", f"/rest/rules/ruleset/?search={requests.utils.quote(name)}")
        for item in resp.json().get("results", []):
            if item.get("name") == name:
                return item
        return None

    def find_source(self, name: str) -> dict | None:
        resp = self.rest("GET", f"/rest/rules/source/?search={requests.utils.quote(name)}")
        for item in resp.json().get("results", []):
            if item.get("name") == name:
                return item
        return None

    def create_source(self, name: str) -> dict:
        log.info("Создаю источник '%s' (method=local, datatype=sigs)", name)
        resp = self.rest(
            "POST",
            "/rest/rules/source/",
            json={"name": name, "method": "local", "datatype": "sigs"},
        )
        return resp.json()

    def ensure_source(self, name: str) -> dict:
        src = self.find_source(name)
        if src:
            return src
        return self.create_source(name)

    # ================= Pull: забрать текущие правила из Clear NDR =================

    def resolve_ruleset_pk(self, ruleset_name: str) -> int:
        rset = self.find_ruleset(ruleset_name)
        if not rset:
            known = [
                i.get("name")
                for i in self.rest("GET", "/rest/rules/ruleset/").json().get("results", [])
            ]
            raise SciriusError(
                f"Ruleset '{ruleset_name}' не найден. Существуют: {', '.join(known) or '—'}"
            )
        return int(rset["pk"])

    def pull_rules_via_export(self, ruleset_pk: int) -> str:
        """Точный активный ruleset: POST /rules/ruleset/<pk>/export/ (нужна веб-сессия)."""
        log.info("Выгружаю ruleset #%s через export (нужна веб-сессия)", ruleset_pk)
        resp = self._web_post(f"/rules/ruleset/{ruleset_pk}/export/", data={"version": "0"})
        return self._scirius_rules_from_tarball(resp.content)

    @staticmethod
    def _scirius_rules_from_tarball(data: bytes) -> str:
        try:
            with tarfile.open(fileobj=io.BytesIO(data), mode="r:*") as tar:
                for member in tar.getmembers():
                    if member.name.endswith(".rules") and member.isfile():
                        fh = tar.extractfile(member)
                        if fh:
                            return fh.read().decode("utf-8", errors="replace")
        except tarfile.TarError as exc:
            raise SciriusError(f"Экспорт ruleset'а не похож на tar.gz: {exc}") from exc
        raise SciriusError("В экспорте ruleset'а не найдено ни одного .rules файла")

    def pull_rules_via_rest(self, ruleset_pk: int) -> str:
        """Фолбэк без веб-сессии: правила включённых категорий ruleset'а через /rest/.

        ВАЖНО: работает медленно (пагинация по 30 записей) и возвращает правила
        включённых категорий БЕЗ учёта точечных отключений/трансформаций.
        Для точного состояния используйте pull_mode = export.
        """
        detail = self.rest("GET", f"/rest/rules/ruleset/{ruleset_pk}/").json()
        category_pks = detail.get("categories", [])
        log.info(
            "REST-выгрузка: ruleset #%s, %d включённых категорий", ruleset_pk, len(category_pks)
        )
        chunks: list[str] = []
        for cat_pk in category_pks:
            page = 1
            while True:
                resp = self.rest(
                    "GET", f"/rest/rules/rule/?category={cat_pk}&page={page}&ordering=sid"
                )
                data = resp.json()
                for rule in data.get("results", []):
                    content = self._latest_content(rule)
                    if content:
                        chunks.append(content if content.endswith("\n") else content + "\n")
                if data.get("next") is None:
                    break
                page += 1
        return "".join(chunks)

    @staticmethod
    def _latest_content(rule: dict) -> str | None:
        versions = rule.get("versions") or []
        best = None
        for v in versions:
            if v.get("state") == 0 or v.get("commented_in_source"):
                continue
            if best is None or (v.get("version") or 0) > (best.get("version") or 0):
                best = v
        if best is None:
            return None
        content = best.get("content") or ""
        return content if content.strip() else None

    def pull_rules(self) -> tuple[str, str]:
        """Забирает текущие правила из Clear NDR. Возвращает (текст, способ)."""
        name = self.cfg.ruleset
        if self.cfg.pull_mode == "dir":
            return self.pull_rules_from_dir(), "dir"
        if self.cfg.pull_mode == "off":
            raise SciriusError("pull_mode=off, а выгрузка запрошена")
        pk = self.resolve_ruleset_pk(name)
        order: list[str]
        if self.cfg.pull_mode == "auto":
            order = ["export", "rest"]
        else:
            order = [self.cfg.pull_mode]
        errors: list[str] = []
        for mode in order:
            try:
                if mode == "export":
                    return self.pull_rules_via_export(pk), "export"
                if mode == "rest":
                    return self.pull_rules_via_rest(pk), "rest"
            except (SciriusAuthError, SciriusError) as exc:
                log.warning("Способ pull=%s не сработал: %s", mode, exc)
                errors.append(f"{mode}: {exc}")
        raise SciriusError("Ни один способ выгрузки не сработал: " + "; ".join(errors))

    def pull_rules_from_dir(self) -> str:
        """Читает ручные экспорты из cleardmr.export_dir (*.rules и *.tgz/*.tar.gz)."""
        d = Path(self.cfg.export_dir).expanduser()
        if not d.is_dir():
            raise SciriusError(f"cleardmr.export_dir не найден: {d}")
        chunks: list[str] = []
        for f in sorted(d.iterdir()):
            if f.suffix == ".rules":
                chunks.append(f.read_text(encoding="utf-8", errors="replace"))
            elif f.suffix in (".tgz", ".gz") and "tar" in f.name:
                chunks.append(self._scirius_rules_from_tarball(f.read_bytes()))
        if not chunks:
            raise SciriusError(f"В {d} нет *.rules или *.tgz файлов")
        return "\n".join(chunks)

    # ================= Push: импорт финального файла в Clear NDR =================

    def upload_source_file(self, source_pk: int, tarball: Path) -> None:
        log.info("Загружаю %s в источник #%s", tarball.name, source_pk)
        with open(tarball, "rb") as fh:
            resp = self.rest(
                "POST",
                f"/rest/rules/source/{source_pk}/upload/",
                files={"file": (tarball.name, fh, "application/gzip")},
            )
        body = resp.json()
        if body.get("upload") != "ok":
            raise SciriusError(f"Upload вернул неожиданный ответ: {body}")

    def source_categories(self, source_pk: int) -> list[int]:
        pks: list[int] = []
        page = 1
        while True:
            resp = self.rest("GET", f"/rest/rules/category/?source={source_pk}&page={page}")
            data = resp.json()
            pks.extend(int(c["pk"]) for c in data.get("results", []))
            if data.get("next") is None:
                break
            page += 1
        return sorted(set(pks))

    def attach_source_to_ruleset(self, ruleset_pk: int, source_pk: int) -> bool:
        """Добавляет источник и его категории в ruleset (PATCH /rest/rules/ruleset/)."""
        detail = self.rest("GET", f"/rest/rules/ruleset/{ruleset_pk}/").json()
        sources = list(detail.get("sources", []))
        categories = list(detail.get("categories", []))
        if source_pk in sources:
            log.info("Источник #%s уже входит в ruleset #%s", source_pk, ruleset_pk)
            return False
        sources.append(source_pk)
        categories.extend(self.source_categories(source_pk))
        log.info(
            "Привязываю источник #%s (категории %s) к ruleset #%s",
            source_pk, categories, ruleset_pk,
        )
        self.rest(
            "PATCH",
            f"/rest/rules/ruleset/{ruleset_pk}/",
            json={"sources": sources, "categories": categories},
        )
        return True

    def trigger_ruleset_update(self, ruleset_pk: int) -> None:
        """POST /rules/ruleset/<pk>/update/ — сборка ruleset'а и пуш в Suricata (сессия)."""
        log.info("Запускаю Update ruleset #%s (сборка и перезагрузка правил на сенсоре)", ruleset_pk)
        resp = self._web_post(f"/rules/ruleset/{ruleset_pk}/update/")
        log.info("Update ruleset принят: HTTP %s", resp.status_code)

    def push(self, tarball: Path, ruleset_name: str, source_name: str, do_update: bool) -> dict:
        """Полный цикл импорта: создать источник (если нет) -> загрузить архив -> привязать -> обновить."""
        summary: dict = {"source_pk": None, "ruleset_pk": None, "attached": False, "updated": False}
        ruleset_pk = self.resolve_ruleset_pk(ruleset_name)
        summary["ruleset_pk"] = ruleset_pk
        src = self.ensure_source(source_name)
        source_pk = int(src["pk"])
        summary["source_pk"] = source_pk
        self.upload_source_file(source_pk, tarball)
        summary["attached"] = self.attach_source_to_ruleset(ruleset_pk, source_pk)
        if do_update:
            try:
                self.trigger_ruleset_update(ruleset_pk)
                summary["updated"] = True
            except SciriusAuthError as exc:
                log.warning(
                    "Автообновление ruleset недоступно: %s\n"
                    "Откройте UI Scirius: Rulesets -> %s -> Actions -> Update ruleset",
                    exc, ruleset_name,
                )
        return summary

    # ================= диагностика =================

    def test_connection(self) -> dict:
        info: dict = {"url": self.base}
        try:
            resp = self.rest("GET", "/rest/rules/ruleset/")
            info["token"] = "ok"
            items = resp.json().get("results", [])
            info["rulesets"] = [i.get("name") for i in items]
        except SciriusError as exc:
            info["token"] = f"ошибка: {exc}"
        try:
            self.web_session()
            info["session"] = "ok"
        except SciriusError as exc:
            info["session"] = f"недоступна: {exc}"
        return info
