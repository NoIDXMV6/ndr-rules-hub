"""Тесты конфигурации."""

import pytest

from snort_rules_sync.config import ConfigError, load_config


def write_cfg(tmp_path, text: str):
    p = tmp_path / "config.toml"
    p.write_text(text, encoding="utf-8")
    return p


def test_minimal_config(tmp_path):
    p = write_cfg(tmp_path, """
[general]
workdir = "/tmp/test-sync"
""")
    cfg = load_config(p)
    assert str(cfg.general.workdir) == "/tmp/test-sync"
    assert cfg.cleardmr.enabled is False
    assert cfg.collisions.strategy == "renumber"


def test_unknown_key_rejected(tmp_path):
    p = write_cfg(tmp_path, """
[snort]
oinkcode_typo = "x"
""")
    with pytest.raises(ConfigError, match="Неизвестный ключ"):
        load_config(p)


def test_invalid_strategy_rejected(tmp_path):
    p = write_cfg(tmp_path, """
[collisions]
strategy = "explode"
""")
    with pytest.raises(ConfigError, match="strategy"):
        load_config(p)


def test_push_requires_credentials(tmp_path):
    p = write_cfg(tmp_path, """
[cleardmr]
enabled = true
url = "https://cleardr.local"
push = true
""")
    with pytest.raises(ConfigError, match="token"):
        load_config(p)


def test_pull_mode_dir_requires_export_dir(tmp_path):
    p = write_cfg(tmp_path, """
[cleardmr]
enabled = true
pull_mode = "dir"
""")
    with pytest.raises(ConfigError, match="export_dir"):
        load_config(p)


def test_env_overrides(tmp_path, monkeypatch):
    monkeypatch.setenv("SNORT_OINKCODE", "abc123")
    monkeypatch.setenv("CLEARDMR_TOKEN", "tok")
    monkeypatch.setenv("SNORT_RULES_SYNC_WORKDIR", "/tmp/env-workdir")
    p = write_cfg(tmp_path, """
[snort]
oinkcode = ""
""")
    cfg = load_config(p)
    assert cfg.snort.oinkcode == "abc123"
    assert cfg.cleardmr.token == "tok"
    assert str(cfg.general.workdir) == "/tmp/env-workdir"


def test_missing_file(tmp_path):
    with pytest.raises(ConfigError, match="не найден"):
        load_config(tmp_path / "nope.toml")


def test_range_validation(tmp_path):
    p = write_cfg(tmp_path, """
[collisions]
range_start = 500
range_end = 100
""")
    with pytest.raises(ConfigError, match="меньше"):
        load_config(p)
