# Диаграммы NDR&DNS Rules HUB — v1.40.0 (срез 2026-11-21)

Единый архив всех схем системы. Полностью синхронизирован с веткой main
(GitHub: NoIDXMV6/ndr-rules-hub, GitVerse: noid/ndr-hub, коммит d7bf31c).

## Состав

1. docs/diagrams/*.puml + *.png — PlantUML:
   - c1-context — C1 контекст (Hub и окружение);
   - c2-containers — C2 контейнеры (компоненты и БД);
   - c3-security — C3 слой безопасности (src/lib/security);
   - seq-download — скачивание правил Clear NDR через /api/export;
   - seq-login-bruteforce — вход и защита от перебора;
   - seq-registration — регистрация и верификация (Enterprise).

2. docs/diagrams/mermaid/*.mmd + *.png — 32 standalone mermaid-схемы (RU+EN),
   извлечённые из architecture.md / architecture.en.md / README / clearndr-доков.
   Имя файла: <документ>-<номер блока>-<заголовок раздела>.mmd|.png.
   registry.json — связь каждого .mmd с файлом-источником и заголовком.
   Ключевые схемы:
   - architecture-04-8-1-proverka-zhivosti-domenov-v1-37-0 — живость доменов
     (делегирование): DomainRecord → dns-alive.ts (батчи, пул 50 DNS, NS/A/AAAA/CNAME)
     → DomainAlive (alive/dead/error) → исключение dead при следующей сборке
     (droppedDead) → blocked-domains.txt;
   - architecture-02 — конвейер обработки правил; architecture-03 — конвейер качества;
   - architecture-01 — компонентная схема; architecture-07 — жизненный цикл запроса;
   - architecture-08..10 / clearndr-integration / clearndr-update — интеграция Clear NDR
     (PULL/PUSH, автообновление); architecture-05/06 — WireGuard up/down.

3. docs/diagrams/interactive/*.html — 8 отрендеренных интерактивных схем (archify,
   standalone HTML, тёмная/светлая тема, экспорт PNG/SVG/WebP, открываются без сервера):
   dns-alive-workflow (живость доменов), component-map, dns-domain-pipeline,
   rules-pipeline, rules-quality-gates, clearndr-delivery, request-lifecycle, cron-cycle.
   Блюпринты-исходники этих схем — в п. 5 (.archify/*/candidate.json).

4. public/diagrams/*.png — схемы Clear NDR (PULL/PUSH/автообновление, RU+EN),
   используемые справкой UI.

5. .archify/*/candidate.json — блюпринты интерактивных схем (archify):
   architecture-components, dataflow-dns-pipeline, dataflow-rules,
   sequence-clearndr, sequence-request, workflow-cron, workflow-dns-alive,
   workflow-quality (срез 2026-11-21).

6. examples/workflow-agent-tool-call-rendered.html — отрендеренный интерактивный
   workflow (standalone HTML).

## Как перегенерировать

- Извлечение .mmd из markdown: python3 scripts/extract-mermaid.py
- PNG-рендеры: python3 scripts/render-mermaid.py [фильтры по имени]
