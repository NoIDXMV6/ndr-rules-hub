"""CLI snort-rules-sync.

Команды:
  sync    Полный цикл: WireGuard -> скачивание -> выгрузка из Clear NDR -> сборка -> (опц.) импорт
  download Только скачать архивы snort.org (через VPN при включённом wireguard)
  pull     Только выгрузить текущие правила Clear NDR в workdir/pull/
  build    Собрать финальный файл из уже скачанных архивов и выгрузки
  push     Импортировать уже собранный tarball в Clear NDR
  check    Проверить конфигурацию и доступность snort.org / Clear NDR
"""

from __future__ import annotations

import argparse
import fcntl
import json
import logging
import sys
from pathlib import Path

import requests

from . import __version__
from .archives import ArchiveError, collect_rule_files, extract_tarball, read_text_safe
from .cleardmr import SciriusClient, SciriusError
from .config import AppConfig, ConfigError, load_config
from .parser import parse_rules
from .pipeline import BuildResult, PipelineError, SourceInput, build_ruleset
from .report import build_tarball, render_rules_file, sha256_of, write_manifest, write_report
from .snort import SnortClient, SnortError
from .wg import WireguardError, ensure_tunnel, bind_session

log = logging.getLogger("cli")

DEFAULT_CONFIG_PATHS = (
    Path("config.toml"),
    Path("/etc/snort-rules-sync/config.toml"),
)

SOURCES_ORDER = ["cleardmr", "snort-registered", "snort-community"]


# --------------------------------------------------------------------------
# вспомогательные функции
# --------------------------------------------------------------------------


def _make_session(app: AppConfig, bind_to_wg: bool) -> requests.Session:
    s = requests.Session()
    if bind_to_wg and app.wireguard.enabled:
        try:
            ensure_tunnel(
                app.wireguard.interface,
                app.wireguard.auto_up,
                app.wireguard.strict,
                app.wireguard.max_handshake_age,
            )
        except WireguardError as exc:
            raise SystemExit(f"ОШИБКА: {exc}")
        if _iface_exists(app.wireguard.interface):
            bind_session(s, app.wireguard.interface)
    return s


def _iface_exists(iface: str) -> bool:
    import subprocess

    return subprocess.run(["ip", "link", "show", iface], capture_output=True).returncode == 0


def _acquire_lock(app: AppConfig) -> int:
    lock_path = Path(app.general.workdir) / "sync.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(lock_path, "w")
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit("ОШИБКА: другой процесс snort-rules-sync уже работает (sync.lock)")
    return fh.fileno()


class _BuildContext:
    """Собирает входные наборы правил для build_ruleset."""

    def __init__(self, app: AppConfig, log_prefix: str = ""):
        self.app = app
        self.notes: list[str] = []

    def collect_inputs(self, archives: dict[str, Path], cleardmr_text: str | None) -> list[SourceInput]:
        inputs: list[SourceInput] = []
        inc = self.app.include

        for name, label in (("registered", "snort-registered"), ("community", "snort-community")):
            archive = archives.get(name)
            if not archive:
                continue
            dest = self.app.extract_dir() / name
            extract_tarball(archive, dest)
            files = collect_rule_files(dest, inc.rules_globs, inc.exclude_globs)
            rules = []
            warnings = 0
            for f in files:
                res = parse_rules(read_text_safe(f), origin=label, file=f.name)
                rules.extend(res.rules)
                warnings += len(res.warnings)
            log.info("%s: %d файлов, %d правил, %d предупреждений", label, len(files), len(rules), warnings)
            self.notes.append(f"{label}: распознано {len(rules)} правил из {len(files)} файлов")
            inputs.append(SourceInput(name=label, priority=SOURCES_ORDER.index(label), rules=rules))

        if cleardmr_text:
            res = parse_rules(cleardmr_text, origin="cleardmr", file="ruleset-export")
            log.info("cleardmr: %d правил (способ: экспорт текущего ruleset)", len(res.rules))
            self.notes.append(f"cleardmr: получено {len(res.rules)} правил")
            inputs.append(SourceInput(name="cleardmr", priority=SOURCES_ORDER.index("cleardmr"), rules=res.rules))

        return inputs

    def occupancy_and_optional_input(
        self, inputs: list[SourceInput]
    ) -> dict[int, "object"]:
        """Возвращает occupancy-словарь sid -> Rule из источника cleardmr.

        При cleardmr.include_rules=true правила Clear NDR одновременно остаются
        и во входном наборе (полный консолидированный файл). При false —
        служат только для дедупликации и ресолва SID.
        """
        occupied: dict[int, object] = {}
        cleardmr = next((i for i in inputs if i.name == "cleardmr"), None)
        if cleardmr is None:
            return occupied
        if not self.app.cleardmr.include_rules:
            for r in cleardmr.rules:
                if r.sid is not None:
                    occupied[r.sid] = r
            inputs.remove(cleardmr)
        else:
            for r in cleardmr.rules:
                if r.sid is not None:
                    occupied[r.sid] = r
        return occupied


def _pull_cleardmr(app: AppConfig) -> str | None:
    cfg = app.cleardmr
    if not cfg.enabled or cfg.pull_mode == "off":
        log.info("Выгрузка из Clear NDR отключена (cleardmr.enabled/pull_mode)")
        return None
    if cfg.pull_mode == "dir":
        return _pull_from_dir(cfg.export_dir)
    client = SciriusClient(cfg)
    text, _mode = client.pull_rules()
    (app.pull_dir() / "cleardmr-ruleset.rules").write_text(text, encoding="utf-8")
    return text


def _pull_from_dir(export_dir: str) -> str:
    from pathlib import Path as _P

    d = _P(export_dir).expanduser()
    if not d.is_dir():
        raise SciriusError(f"cleardmr.export_dir не найден: {d}")
    chunks = [f.read_text(encoding="utf-8", errors="replace") for f in sorted(d.glob("*.rules"))]
    for f in sorted(d.glob("*.tgz")) + sorted(d.glob("*.tar.gz")):
        import io, tarfile

        with tarfile.open(f, "r:*") as tar:
            for m in tar.getmembers():
                if m.isfile() and m.name.endswith(".rules"):
                    fh = tar.extractfile(m)
                    if fh:
                        chunks.append(fh.read().decode("utf-8", errors="replace"))
    if not chunks:
        raise SciriusError(f"В {d} нет *.rules / *.tgz файлов")
    return "\n".join(chunks)


def _write_outputs(app: AppConfig, result: BuildResult, notes: list[str]) -> tuple[Path, Path]:
    out = app.output_dir()
    rules_text = render_rules_file(result)
    rules_path = out / "final.rules"
    rules_path.write_text(rules_text, encoding="utf-8")
    tarball_path = build_tarball(rules_text, app.cleardmr.source_name, out / "snort-sync.tar.gz")
    write_manifest(result, out, extra={"final_rules_sha256": sha256_of(rules_path)})
    write_report(result, out, notes=notes)
    log.info("Готово: %s, %s, %s, %s", rules_path, tarball_path, out / "manifest.json", out / "report.md")
    return rules_path, tarball_path


# --------------------------------------------------------------------------
# команды
# --------------------------------------------------------------------------


def cmd_sync(app: AppConfig, args) -> int:
    _acquire_lock(app)
    session = _make_session(app, bind_to_wg=True)
    snort = SnortClient(app.snort, session)

    archives: dict[str, Path] = {}
    archives["community"] = snort.get_community_rules(app.archives_dir(), force=args.force)
    reg = snort.get_registered_rules(app.archives_dir(), force=args.force)
    if reg:
        archives["registered"] = reg

    cleardmr_text = _pull_cleardmr(app)

    ctx = _BuildContext(app)
    inputs = ctx.collect_inputs(archives, cleardmr_text)
    occupied = ctx.occupancy_and_optional_input(inputs)
    result = build_ruleset(inputs, app.collisions, occupied=occupied)
    _, tarball = _write_outputs(app, result, ctx.notes)

    if app.cleardmr.push:
        client = SciriusClient(app.cleardmr)
        summary = client.push(
            tarball, app.cleardmr.ruleset, app.cleardmr.source_name, do_update=True
        )
        log.info("Импорт в Clear NDR: %s", json.dumps(summary, ensure_ascii=False))
        print(json.dumps(summary, ensure_ascii=False))
    return 0


def cmd_download(app: AppConfig, args) -> int:
    session = _make_session(app, bind_to_wg=True)
    snort = SnortClient(app.snort, session)
    p1 = snort.get_community_rules(app.archives_dir(), force=args.force)
    print(f"community: {p1}")
    p2 = snort.get_registered_rules(app.archives_dir(), force=args.force)
    print(f"registered: {p2 if p2 else 'пропущен (нет oinkcode)'}")
    return 0


def cmd_pull(app: AppConfig, args) -> int:
    text = _pull_cleardmr(app)
    out = app.pull_dir() / "cleardmr-ruleset.rules"
    out.write_text(text or "", encoding="utf-8")
    print(f"Выгружено в {out} ({len((text or '').splitlines())} строк)")
    return 0


def cmd_build(app: AppConfig, args) -> int:
    _acquire_lock(app)
    archives: dict[str, Path] = {}
    comm = _latest_archive(app.archives_dir(), "community-rules-*.tar.gz")
    if comm:
        archives["community"] = comm
    reg = _latest_archive(app.archives_dir(), "snortrules-snapshot-*-*.tar.gz")
    if reg:
        archives["registered"] = reg
    if not archives:
        raise SystemExit("ОШИБКА: в workdir/archives нет скачанных архивов — сначала 'sync' или 'download'")

    cleardmr_text = _pull_cleardmr(app)
    ctx = _BuildContext(app)
    inputs = ctx.collect_inputs(archives, cleardmr_text)
    occupied = ctx.occupancy_and_optional_input(inputs)
    result = build_ruleset(inputs, app.collisions, occupied=occupied)
    _write_outputs(app, result, ctx.notes)
    return 0


def cmd_push(app: AppConfig, args) -> int:
    tarball = app.output_dir() / "snort-sync.tar.gz"
    if not tarball.is_file():
        raise SystemExit(f"ОШИБКА: {tarball} не найден — сначала 'sync' или 'build'")
    client = SciriusClient(app.cleardmr)
    summary = client.push(tarball, app.cleardmr.ruleset, app.cleardmr.source_name, do_update=True)
    print(json.dumps(summary, ensure_ascii=False))
    return 0


def cmd_check(app: AppConfig, args) -> int:
    ok = True
    print(f"Конфигурация: OK (workdir={app.general.workdir})")
    session = _make_session(app, bind_to_wg=app.wireguard.enabled)
    snort = SnortClient(app.snort, session)
    try:
        v = snort.detect_snapshot_version()
        print(f"snort.org: OK, актуальная версия снапшота: {v}")
        if app.snort.oinkcode:
            print("oinkcode: задан — registered-снапшот будет скачиваться")
        else:
            print("oinkcode: НЕ задан — будут скачиваться только community rules")
    except (SnortError, requests.RequestException) as exc:
        ok = False
        print(f"snort.org: ОШИБКА — {exc}")

    if app.cleardmr.enabled and app.cleardmr.url:
        try:
            info = SciriusClient(app.cleardmr).test_connection()
            print(f"Clear NDR ({info['url']}):")
            print(f"  token:   {info.get('token')}")
            print(f"  session: {info.get('session')}")
            if info.get("rulesets"):
                print(f"  rulesets: {', '.join(info['rulesets'])}")
        except SciriusError as exc:
            ok = False
            print(f"Clear NDR: ОШИБКА — {exc}")
    return 0 if ok else 1


def _latest_archive(archives_dir: Path, pattern: str) -> Path | None:
    files = sorted(archives_dir.glob(pattern))
    return files[-1] if files else None


# --------------------------------------------------------------------------
# точка входа
# --------------------------------------------------------------------------


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="snort-rules-sync",
        description="Синхронизация правил Snort в Clear NDR (Scirius): скачивание через "
        "WireGuard, дедупликация, устранение пересечений SID, импорт.",
    )
    p.add_argument("--config", "-c", help="путь к config.toml (по умолчанию ./config.toml)")
    p.add_argument("--version", action="version", version=f"snort-rules-sync {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    for name, help_text in (
        ("sync", "полный цикл: скачать + выгрузить + собрать + (опц.) импортировать"),
        ("download", "только скачать архивы snort.org"),
        ("pull", "только выгрузить текущие правила Clear NDR"),
        ("build", "собрать финальный файл из скачанных архивов"),
        ("push", "импортировать собранный tarball в Clear NDR"),
        ("check", "проверить конфигурацию и связность"),
    ):
        sp = sub.add_parser(name, help=help_text)
        # --config можно указывать и после подкоманды (удобно в cron)
        sp.add_argument("--config", "-c", default=argparse.SUPPRESS,
                        help="путь к config.toml")
        if name in ("sync", "download"):
            sp.add_argument("--force", action="store_true", help="скачать заново, игнорируя кэш")
        sp.set_defaults(func=globals()[f"cmd_{name}"])
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        stream=sys.stdout,
    )

    try:
        cfg_path = args.config
        if cfg_path is None:
            for cand in DEFAULT_CONFIG_PATHS:
                if cand.is_file():
                    cfg_path = cand
                    break
        app = load_config(cfg_path)
    except ConfigError as exc:
        print(f"ОШИБКА КОНФИГА: {exc}", file=sys.stderr)
        return 2

    try:
        return args.func(app, args)
    except (SnortError, SciriusError, ArchiveError, PipelineError) as exc:
        log.error("%s", exc)
        print(f"ОШИБКА: {exc}", file=sys.stderr)
        return 1
    except requests.RequestException as exc:
        log.error("Сетевая ошибка: %s", exc)
        print(f"ОШИБКА СЕТИ: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
