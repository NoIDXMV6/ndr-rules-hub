"""Конвейер обработки правил: дедупликация и устранение пересечений SID.

Алгоритм (порядок приоритетов задаётся списком источников — первым самый главный):

1. Дедупликация по содержимому: полностью одинаковые правила (после нормализации
   пробелов) остаются один раз — от источника с высшим приоритетом.
2. Пересечения SID внутри загруженных архивов:
   * одинаковый msg и разный rev -> остаётся правило с максимальным rev
     (это одна и та же сигнатура в разных версиях);
   * разный msg -> побеждает источник с высшим приоритетом, остальные
     перенумеровываются (strategy=renumber) или отбрасываются (strategy=drop).
3. Пересечения с правилами, уже живущими в Clear NDR (occupancy-множество,
   полученное из экспорта текущего ruleset'а):
   * идентичное содержимое -> правило отбрасывается (дубликат);
   * тот же msg и БОЛЕЕ новый rev (same_msg_newer_rev=upgrade) -> оставляем
     под тем же SID, Scirius обновит сигнатуру при импорте;
   * иначе -> переносим в свободный локальный диапазон SID
     (по умолчанию 1000000-1999999) либо отбрасываем (strategy=drop).

Диапазон 1000000-1999999 — официально выделенный под локальные правила
Snort/Suricata, он не пересекается с диапазонами Talos (1-999999... фактически
Talos использует до ~999999), ET (2xxxxxx) и вендоров.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from .config import CollisionsConfig
from .parser import Rule

log = logging.getLogger("pipeline")


class PipelineError(Exception):
    pass


@dataclass
class SourceInput:
    """Набор правил одного источника. Меньший priority = выше важность."""

    name: str
    priority: int
    rules: list[Rule]

    def sorted_rules(self) -> list[Rule]:
        return self.rules


@dataclass
class BuildStats:
    per_source_total: dict[str, int] = field(default_factory=dict)
    dropped_identical: list[dict] = field(default_factory=list)   # {sid,msg,kept_by,duplicate_of}
    dropped_superseded: list[dict] = field(default_factory=list)  # {sid,rev,kept_rev,source}
    dropped_collisions: list[dict] = field(default_factory=list)  # {sid,msg,source,reason}
    renumbered: list[dict] = field(default_factory=list)          # {old_sid,new_sid,msg,source,reason}
    upgraded: list[dict] = field(default_factory=list)            # {sid,old_rev,new_rev,source}
    total_input: int = 0
    total_output: int = 0

    def summary(self) -> str:
        parts = [f"вход: {self.total_input}", f"итог: {self.total_output}"]
        if self.dropped_identical:
            parts.append(f"дубликатов удалено: {len(self.dropped_identical)}")
        if self.dropped_superseded:
            parts.append(f"устаревших версий удалено: {len(self.dropped_superseded)}")
        if self.renumbered:
            parts.append(f"перенумеровано SID: {len(self.renumbered)}")
        if self.upgraded:
            parts.append(f"обновлено до новой rev: {len(self.upgraded)}")
        if self.dropped_collisions:
            parts.append(f"коллизий отброшено: {len(self.dropped_collisions)}")
        return "; ".join(parts)


@dataclass
class BuildResult:
    rules: list[Rule]
    stats: BuildStats
    sources_order: list[str]


class _SidPool:
    """Детерминированный генератор свободных SID из диапазона."""

    def __init__(self, start: int, end: int, used: set[int]):
        self._start = start
        self._end = end
        self._used = set(used)
        self._next = start
        self.exhausted = False

    def take(self) -> int:
        while self._next <= self._end:
            cand = self._next
            self._next += 1
            if cand not in self._used:
                self._used.add(cand)
                return cand
        self.exhausted = True
        raise PipelineError(
            f"Диапазон SID {self._start}-{self._end} исчерпан: "
            "увеличьте collisions.range_end или смените strategy=drop"
        )


def _rule_sort_key(rule: Rule) -> tuple:
    return (rule.origin, rule.file, rule.raw)


def build_ruleset(
    inputs: list[SourceInput],
    collisions: CollisionsConfig,
    occupied: dict[int, Rule] | None = None,
) -> BuildResult:
    """Собирает итоговый список правил без дублей и пересечений SID.

    occupied — правила, уже существующие в Clear NDR (sid -> Rule).
    """
    occupied = occupied or {}
    stats = BuildStats()
    for inp in inputs:
        stats.per_source_total[inp.name] = len(inp.rules)
        stats.total_input += len(inp.rules)

    ordered = sorted(inputs, key=lambda i: (i.priority, i.name))
    sources_order = [i.name for i in ordered]

    # --- 1. дедупликация по содержимому ---
    seen_by_digest: dict[str, Rule] = {}
    unique: list[Rule] = []
    for inp in ordered:
        for rule in inp.sorted_rules():
            existing = seen_by_digest.get(rule.digest)
            if existing is not None:
                stats.dropped_identical.append(
                    {
                        "sid": rule.sid,
                        "msg": rule.msg,
                        "kept_by": existing.origin,
                        "duplicate_of": inp.name,
                    }
                )
                continue
            seen_by_digest[rule.digest] = rule
            unique.append(rule)

    # --- 2. пересечения SID внутри набора ---
    by_sid: dict[int, list[Rule]] = {}
    no_sid: list[Rule] = []
    for rule in unique:
        if rule.sid is None:
            log.warning("Правило без sid пропущено: %s", rule.normalized[:120])
            continue
        by_sid.setdefault(rule.sid, []).append(rule)

    survivors: list[Rule] = []
    pool_seed: set[int] = set()
    for sid, group in by_sid.items():
        if len(group) == 1:
            survivors.append(group[0])
            pool_seed.add(sid)
            continue
        msgs = {r.msg for r in group}
        if len(msgs) == 1:
            # одна сигнатура, разные версии: оставляем самую свежую rev
            winner = max(group, key=lambda r: (r.rev or 0))
            survivors.append(winner)
            pool_seed.add(sid)
            for loser in group:
                if loser is winner:
                    continue
                stats.dropped_superseded.append(
                    {
                        "sid": sid,
                        "rev": loser.rev,
                        "kept_rev": winner.rev,
                        "source": loser.origin,
                    }
                )
        else:
            # разные сигнатуры на одном SID: приоритет решает
            group_sorted = sorted(group, key=_rule_sort_key)  # стабильность
            winner = group_sorted[0]
            survivors.append(winner)
            pool_seed.add(sid)
            for loser in group_sorted[1:]:
                if collisions.strategy == "drop":
                    stats.dropped_collisions.append(
                        {
                            "sid": sid,
                            "msg": loser.msg,
                            "source": loser.origin,
                            "reason": f"пересечение с правилом из {winner.origin}",
                        }
                    )
                else:
                    survivors.append(loser)
                    loser.flags.add("needs_renumber")

    # --- 3. пересечения с уже существующими правилами Clear NDR ---
    pool = _SidPool(collisions.range_start, collisions.range_end, pool_seed | set(occupied))
    final: list[Rule] = []
    final_sids: set[int] = set()

    def _renumber(rule: Rule, reason: str) -> None:
        new_sid = pool.take()
        rule.final_sid = new_sid
        rule.flags.add("renumbered")
        final.append(rule)
        final_sids.add(new_sid)
        stats.renumbered.append(
            {"old_sid": rule.sid, "new_sid": new_sid, "msg": rule.msg,
             "source": rule.origin, "reason": reason}
        )

    for rule in survivors:
        sid = rule.sid
        assert sid is not None

        # Проигравший внутреннего конфликта: обязан получить новый SID
        # независимо от занятости в Clear NDR.
        if "needs_renumber" in rule.flags:
            _renumber(rule, "внутреннее пересечение SID между источниками")
            continue

        occupier = occupied.get(sid)
        # Правило из того же источника, что и запись occupier (режим консолидации:
        # правила Clear NDR сверяются сами с собой) — не трогаем.
        if occupier is not None and rule.origin == occupier.origin:
            rule.final_sid = sid
            final.append(rule)
            final_sids.add(sid)
            continue
        if occupier is None:
            rule.final_sid = sid
            final.append(rule)
            final_sids.add(sid)
            continue

        if rule.digest == occupier.digest:
            stats.dropped_identical.append(
                {
                    "sid": sid,
                    "msg": rule.msg,
                    "kept_by": f"cleardmr/{occupier.origin or 'ruleset'}",
                    "duplicate_of": rule.origin,
                }
            )
            continue

        same_msg = bool(rule.msg) and rule.msg == occupier.msg
        newer_rev = (rule.rev or 0) > (occupier.rev or 0)
        if same_msg and newer_rev and collisions.same_msg_newer_rev == "upgrade":
            rule.final_sid = sid
            rule.flags.add("upgrade")
            final.append(rule)
            final_sids.add(sid)
            stats.upgraded.append(
                {"sid": sid, "old_rev": occupier.rev, "new_rev": rule.rev, "source": rule.origin}
            )
            continue

        if collisions.strategy == "drop":
            stats.dropped_collisions.append(
                {
                    "sid": sid,
                    "msg": rule.msg,
                    "source": rule.origin,
                    "reason": f"SID занят в Clear NDR ({occupier.msg[:60]})",
                }
            )
            continue

        _renumber(rule, f"SID занят в Clear NDR ({occupier.msg[:60]})")

    # --- финальные проверки (defense in depth) ---
    seen: set[int] = set()
    for rule in final:
        sid = rule.effective_sid
        assert sid is not None
        if sid in seen:
            raise PipelineError(f"Внутренняя ошибка: дублирующийся итоговый SID {sid}: {rule.msg}")
        seen.add(sid)

    stats.total_output = len(final)
    log.info("Сборка завершена: %s", stats.summary())
    return BuildResult(rules=final, stats=stats, sources_order=sources_order)
