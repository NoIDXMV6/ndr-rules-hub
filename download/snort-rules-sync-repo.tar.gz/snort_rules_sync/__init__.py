"""snort-rules-sync — синхронизация правил Snort в Clear NDR (Scirius)."""

__version__ = "1.0.0"
