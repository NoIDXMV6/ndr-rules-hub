# snort-rules-sync

Синхронизация правил **Snort** (Talos community + registered snapshot) в **Clear NDR** (Scirius):
скачивание через WireGuard-туннель → разбор архивов → учёт уже загруженных в Clear NDR правил →
удаление дубликатов → устранение пересечений **SID** → готовый файл/архив для импорта,
вплоть до полностью автоматического импорта через REST API Scirius.

> Почему это нужно: в Scirius `Rule.sid` — глобальный первичный ключ. Импорт источника,
> в котором встречается SID, уже занятый другим источником, приводит к ошибке
> `DuplicateSidException` («The source contains conflicting SID ... with other source ...»)
> или к перетаскиванию правила из одного источника в другой. Этот скрипт гарантирует,
> что в импортируемом файле нет ни дубликатов, ни пересечений SID с текущим содержимым
> вашего Clear NDR.

## Как это работает

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              cron / systemd timer                           │
└──────────────────────────────────────────┬──────────────────────────────────┘
                                           ▼
                        1. Проверка WireGuard-туннеля (wg0)
                        2. Скачивание со snort.org (трафик привязан к wg0)
                             • community-rules.tar.gz          (без авторизации)
                             • snortrules-snapshot-<VER>.tar.gz/<OINKCODE>
                               (версия определяется автоматически)
                        3. Выгрузка текущих правил из Clear NDR (Scirius)
                             • export ruleset'а (веб-сессия) — точное состояние
                             • или REST /rest/rules/rule/ (token) — фолбэк
                             • или локальные экспорты *.rules/*.tgz (pull_mode=dir)
                        4. Разбор правил, дедупликация, ресолв SID
                        5. Артефакты в workdir/dist:
                             • final.rules          — плоский файл правил
                             • snort-sync.tar.gz    — источник Scirius (rules/*.rules)
                             • manifest.json        — карта перенумераций, статистика
                             • report.md            — отчёт для человека
                        6. (опционально) Автоимпорт в Clear NDR:
                             создать источник -> upload tarball -> привязать к ruleset
                             -> POST /rules/ruleset/<pk>/update/ (перегенерация + reload)
```

### Алгоритм обработки правил

Приоритет источников (сверху вниз, первый главный): `cleardmr` → `snort-registered` → `snort-community`.

1. **Дедупликация по содержимому.** Полностью одинаковые правила (после нормализации
   пробелов вне кавычек и отбрасывания хвостовых комментариев) остаются один раз —
   от источника с высшим приоритетом. Это убирает основную массу пересечений:
   community-набор почти целиком входит в registered-снапшот.
2. **Пересечения SID внутри набора:**
   * одинаковый `msg`, разный `rev` — остаётся самая свежая ревизия;
   * разный `msg` — побеждает источник с высшим приоритетом, остальные
     **перенумеровываются** в локальный диапазон (или отбрасываются при `strategy=drop`).
3. **Пересечения с уже существующими правилами Clear NDR** (occupancy-множество из
   экспорта текущего ruleset'а):
   * идентичное содержимое → правило отбрасывается (дубликат, уже есть в системе);
   * тот же `msg` и более новый `rev` (по умолчанию `same_msg_newer_rev=upgrade`) →
     правило остаётся под тем же SID: Scirius обновит сигнатуру при импорте;
   * иначе → **перенумерация** в свободный SID из диапазона `1000000–1999999`
     (официально выделенный диапазон локальных правил Snort/Suricata), с записью
     соответствия старый→новый SID в `manifest.json` и комментарием в файле.

## Установка

```bash
git clone https://github.com/NoIDXMV6/snort-rules-sync.git
cd snort-rules-sync
python3 -m venv venv
venv/bin/pip install .
# для тестов:
venv/bin/pip install .[dev]
venv/bin/pytest
```

Требования: Python ≥ 3.10, `requests`. Для привязки трафика к WireGuard-интерфейсу —
запуск от root (или CAP_NET_RAW), утилиты `ip`/`wg`.

## Настройка

```bash
cp config.example.toml config.toml
vi config.toml
```

Ключевые параметры:

| Параметр | Описание |
|---|---|
| `snort.oinkcode` | Oinkcode активного (registered) аккаунта snort.org: профиль → Oinkcode. Пусто — только community rules. Лучше задавать через `SNORT_OINKCODE`. |
| `snort.snapshot_version` | Пусто = версия снапшота определяется автоматически со страницы snort.org/downloads. |
| `wireguard.*` | Проверка туннеля перед скачиванием и привязка HTTP-трафика к интерфейсу (`SO_BINDTODEVICE`). `strict=true` — запретить работу без туннеля. |
| `cleardmr.url` | Базовый URL веб-интерфейса Scirius (Clear NDR). |
| `cleardmr.token` | REST-токен: Scirius → иконка пользователя → User Settings → Edit Token → Regenerate. Или env `CLEARDMR_TOKEN`. |
| `cleardmr.username/password` | Веб-сессия для экспорта ruleset'а и команды «Update ruleset» (эти view token не принимают). Или env `CLEARDMR_PASSWORD`. |
| `cleardmr.ruleset` | Имя ruleset'а, с которым сверяемся и в который импортируем (по умолчанию `default`). |
| `cleardmr.pull_mode` | `auto` (export → REST), `export`, `rest`, `dir` (ручные экспорты), `off`. |
| `cleardmr.include_rules` | `false` (рекомендуется) — в финальный файл идут только правила snort.org, уже занятые SID пропускаются/перенумеровываются. `true` — консолидированный файл «всё в одном» для нового пустого ruleset'а. |
| `cleardmr.push` | `true` — полностью автоматический импорт (создание источника, загрузка, привязка, Update ruleset). |
| `collisions.*` | Стратегия коллизий SID (`renumber`/`drop`), диапазон перенумерации, поведение при более новой rev. |

### Проверка окружения

```bash
snort-rules-sync check --config config.toml
```
Покажет: актуальную версию снапшота snort.org, наличие oinkcode, статус token/сессии
Clear NDR и список ruleset'ов.

## Использование

```bash
snort-rules-sync sync   --config config.toml    # полный цикл
snort-rules-sync download --config config.toml  # только скачать архивы
snort-rules-sync pull   --config config.toml    # только выгрузить правила из Clear NDR
snort-rules-sync build  --config config.toml    # собрать файлы из уже скачанных архивов
snort-rules-sync push   --config config.toml    # импортировать собранный tarball в Clear NDR
```

Результат в `${workdir}/dist/`:

* **`final.rules`** — финальный файл правил (плоский, с комментариями-разделителями
  по источникам и пометками о перенумерации SID);
* **`snort-sync.tar.gz`** — архив для импорта в Scirius (файл лежит в `rules/`);
* **`manifest.json`** — полная статистика и карта перенумераций SID (аудит);
* **`report.md`** — человекочитаемый отчёт.

## Импорт в Clear NDR

### Вручную (через UI Scirius)

1. `Sources → Add custom source`:
   * **Name:** `snort-sync` (как в `cleardmr.source_name`);
   * **Method:** `Upload`;
   * **Datatype:** `Signatures files in tar archive`;
   * загрузите `dist/snort-sync.tar.gz`.
2. В ruleset `default` добавьте источник (Sources → отметить → enable категорию `snort-sync`).
3. `Actions → Update ruleset` — пересборка и применение правил на сенсоре.

При повторных запусках скрипта достаточно повторить шаг 1 (upload в тот же источник) и шаг 3.

### Автоматически (`cleardmr.push = true`)

Скрипт сам через API Scirius:

1. находит или создаёт источник `snort-sync` (`POST /rest/rules/source/`,
   `method=local`, `datatype=sigs`) — с token-аутентификацией;
2. загружает свежий tarball (`POST /rest/rules/source/<pk>/upload/`);
3. привязывает источник к ruleset `default` вместе с его категориями
   (`PATCH /rest/rules/ruleset/<pk>/`), если он ещё не привязан;
4. запускает пересборку и применение правил (`POST /rules/ruleset/<pk>/update/`) —
   для этого нужна веб-сессия (`cleardmr.username/password`); если сессия не задана,
   скрипт пропустит только этот шаг и подскажет, что нажать в UI.

После первого импорта в ruleset `default` появится категория `snort-sync`. Все
пересечения SID с другими источниками уже устранены — ошибки
`DuplicateSidException` при обновлении источников не возникнут.

## Расписание (cron / systemd)

Готовые примеры: [`deploy/cron/snort-rules-sync`](deploy/cron/snort-rules-sync),
[`deploy/systemd/snort-rules-sync.service`](deploy/systemd/snort-rules-sync.service) +
[`snort-rules-sync.timer`](deploy/systemd/snort-rules-sync.timer).

cron (ежедневно в 05:17):

```cron
17 5 * * *  /opt/snort-rules-sync/venv/bin/snort-rules-sync sync --config /etc/snort-rules-sync/config.toml >> /var/log/snort-rules-sync.log 2>&1
```

Особенности поведения при работе по расписанию:

* параллельные запуски блокируются (`workdir/sync.lock`);
* архив за текущие сутки не скачивается повторно; при ошибке сети используется
  свежий кэш (`use_cache_on_error`);
* snort.org ограничивает частоту скачивания правил (окно ~15 минут) — частый cron
  не нужен и вреден;
* если туннель не поднялся и `wireguard.strict=true` — запуск завершается ошибкой,
  правила не качаются с внешнего IP мимо VPN.

## Тесты

```bash
pip install .[dev]
pytest
```

59 тестов, включая end-to-end: поднимаются фейковые серверы snort.org (страница
версий, community-архив, reg-rules с проверкой oinkcode, ответ 500 для повтора,
кэш-фолбэк) и Scirius (token + session/CSRF аутентификация, DRF-эндпоинты,
экспорт ruleset'а, upload, update) — и прогоняется полный цикл `sync` вплоть до
проверки, что источник создан, архив загружен, ruleset обновлён.

## Ограничения и заметки

* REST-фолбэк выгрузки правил (`pull_mode=rest`) идёт страницами по 30 правил —
  на больших ruleset'ах это медленно; для точного и быстрого результата используйте
  `export` (веб-сессия) или `dir` (ручной экспорт из UI: Ruleset → Export).
* В режиме `pull_mode=rest` не учитываются точечные отключения правил внутри
  категорий — occupancy-множество получается чуть шире фактического. На ресолв SID
  это влияет консервативно (больше SID считается занятыми).
* Токен и пароль лучше хранить в переменных окружения (`SNORT_OINKCODE`,
  `CLEARDMR_TOKEN`, `CLEARDMR_PASSWORD`), а не в config.toml.
* Привязка к WireGuard (`SO_BINDTODEVICE`) требует root/CAP_NET_RAW и Linux;
  без них скрипт предупредит и продолжит без привязки (или упадёт при `strict=true`).

## Лицензия

MIT
