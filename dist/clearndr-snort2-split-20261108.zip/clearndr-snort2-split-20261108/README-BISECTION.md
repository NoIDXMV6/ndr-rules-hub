# Бисекция файла Talos Snort 2.9 для поиска ошибки импорта Clear NDR

Дата: 2026-11-07. Исходный файл: `clearndr-src-talos-snort2-converted-20261107.rules`
(45,992 правил, sha256 4674523fcf45328dc9ab0258ffbe78624b8b78ac1068102c7b7be0628c5f4e84).
Правила в частях НЕ изменялись (байт-в-байт), суммы SID уникальны, все в блоке clearndr.

## ГЛАВНЫЕ ПОДОЗРЕВАЕМЫЕ

Файл `0-suspects/` содержит правила длиннее 4000 байт (Suricata допускает до 8192,
парсер Clear NDR может иметь меньший лимит):

- строка 36180 исходного файла, sid:1009224895, длина 4109 байт: `MALWARE-OTHER Win.Trojan.Ircbot-7910553-0 download attempt`
- строка 36181 исходного файла, sid:1078107889, длина 4053 байт: `MALWARE-OTHER Win.Trojan.Ircbot-7910553-0 download attempt`

## Порядок тестирования (каждый файл — в ОТДЕЛЬНЫЙ ЧИСТЫЙ источник Clear NDR)

1. Перед КАЖДЫМ импортом источник должен быть пуст: удалите правила прошлых попыток
   (остатки правил дают ошибку «conflicting SID in same source» и маскируют реальную проблему).
2. **Шаг 0:** `0-suspects/clearndr-talos2-suspects-*.rules` (2 правила).
   Упал → виновник найден (одно из двух длинных правил), сообщите — исключу его.
3. **Шаг 1:** 4 файла из `1-by-category/`. Запомните, какие прошли, какой упал.
4. **Шаг 2:** в упавшей категории импортируйте её части из `2-by-classtype/` (каждую в свой источник).
5. Импортировавшийся с ошибкой файл назовите в отчёте: имя файла + точный текст ошибки.
6. Если ВСЕ части прошли, а полный файл падал — проблема в объёме (45 992 правила / 25 МБ за раз),
   а не в конкретном правиле: тогда импортируйте части постоянного размера по ~5 000 правил.

## Таблица лога импорта (заполняйте по мере тестов)

| Файл | Правил | Результат (OK / текст ошибки) |
|---|---|---|
| `1-by-category/clearndr-talos2-cat-malware-cnc-20261108.rules` | 11,885 | |
| `1-by-category/clearndr-talos2-cat-exploits-web-20261108.rules` | 25,849 | |
| `1-by-category/clearndr-talos2-cat-recon-dos-20261108.rules` | 2,785 | |
| `1-by-category/clearndr-talos2-cat-policy-info-20261108.rules` | 5,473 | |
| `2-by-classtype/clearndr-talos2-ct-attempted-admin-20261108.rules` | 4,710 | |
| `2-by-classtype/clearndr-talos2-ct-attempted-dos-20261108.rules` | 996 | |
| `2-by-classtype/clearndr-talos2-ct-attempted-recon-20261108.rules` | 1,011 | |
| `2-by-classtype/clearndr-talos2-ct-attempted-user-p1of4-20261108.rules` | 5,000 | |
| `2-by-classtype/clearndr-talos2-ct-attempted-user-p2of4-20261108.rules` | 5,000 | |
| `2-by-classtype/clearndr-talos2-ct-attempted-user-p3of4-20261108.rules` | 5,000 | |
| `2-by-classtype/clearndr-talos2-ct-attempted-user-p4of4-20261108.rules` | 840 | |
| `2-by-classtype/clearndr-talos2-ct-bad-unknown-20261108.rules` | 71 | |
| `2-by-classtype/clearndr-talos2-ct-default-login-attempt-20261108.rules` | 50 | |
| `2-by-classtype/clearndr-talos2-ct-denial-of-service-20261108.rules` | 361 | |
| `2-by-classtype/clearndr-talos2-ct-misc-activity-20261108.rules` | 2,652 | |
| `2-by-classtype/clearndr-talos2-ct-misc-attack-20261108.rules` | 391 | |
| `2-by-classtype/clearndr-talos2-ct-network-scan-20261108.rules` | 19 | |
| `2-by-classtype/clearndr-talos2-ct-non-standard-protocol-20261108.rules` | 21 | |
| `2-by-classtype/clearndr-talos2-ct-not-suspicious-20261108.rules` | 5 | |
| `2-by-classtype/clearndr-talos2-ct-policy-violation-20261108.rules` | 1,563 | |
| `2-by-classtype/clearndr-talos2-ct-protocol-command-decode-20261108.rules` | 452 | |
| `2-by-classtype/clearndr-talos2-ct-rpc-portmap-decode-20261108.rules` | 123 | |
| `2-by-classtype/clearndr-talos2-ct-shellcode-detect-20261108.rules` | 338 | |
| `2-by-classtype/clearndr-talos2-ct-string-detect-20261108.rules` | 6 | |
| `2-by-classtype/clearndr-talos2-ct-successful-admin-20261108.rules` | 16 | |
| `2-by-classtype/clearndr-talos2-ct-successful-recon-limited-20261108.rules` | 294 | |
| `2-by-classtype/clearndr-talos2-ct-successful-user-20261108.rules` | 6 | |
| `2-by-classtype/clearndr-talos2-ct-suspicious-filename-detect-20261108.rules` | 22 | |
| `2-by-classtype/clearndr-talos2-ct-suspicious-login-20261108.rules` | 30 | |
| `2-by-classtype/clearndr-talos2-ct-system-call-detect-20261108.rules` | 5 | |
| `2-by-classtype/clearndr-talos2-ct-trojan-activity-p1of3-20261108.rules` | 5,000 | |
| `2-by-classtype/clearndr-talos2-ct-trojan-activity-p2of3-20261108.rules` | 5,000 | |
| `2-by-classtype/clearndr-talos2-ct-trojan-activity-p3of3-20261108.rules` | 1,885 | |
| `2-by-classtype/clearndr-talos2-ct-unknown-20261108.rules` | 3 | |
| `2-by-classtype/clearndr-talos2-ct-unsuccessful-user-20261108.rules` | 11 | |
| `2-by-classtype/clearndr-talos2-ct-web-application-activity-20261108.rules` | 557 | |
| `2-by-classtype/clearndr-talos2-ct-web-application-attack-20261108.rules` | 4,554 | |
| `0-suspects/clearndr-talos2-suspects-longrules-20261108.rules` | 2 | |

## Проверка целостности

`sha256sum -c SHA256SUMS.txt`
