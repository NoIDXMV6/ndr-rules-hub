"""Проверка WireGuard-туннеля и привязка HTTP-трафика к его интерфейсу.

Скрипт НЕ сам поднимает туннель по умолчанию (только если wireguard.auto_up = true
и запуск от root): предполагается, что wg0 управляется wg-quick/systemd.
Перед скачиванием проверяется существование интерфейса; при включённом strict
любая проблема с туннелем приводит к ошибке запуска (чтобы правила не качались
в обход VPN с боевого IP).
"""

from __future__ import annotations

import logging
import socket
import subprocess
import time

import requests
from requests.adapters import HTTPAdapter

log = logging.getLogger("wireguard")


class WireguardError(Exception):
    pass


def _run(cmd: list[str]) -> tuple[int, str]:
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return proc.returncode, (proc.stdout + proc.stderr).strip()
    except FileNotFoundError:
        return 127, f"команда не найдена: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, f"таймаут команды: {' '.join(cmd)}"


def _iface_exists(iface: str) -> bool:
    code, _ = _run(["ip", "link", "show", iface])
    return code == 0


def _last_handshake(iface: str) -> int | None:
    code, out = _run(["wg", "show", iface, "latest-handshakes"])
    if code != 0:
        return None
    for token in out.split():
        if token.isdigit():
            return int(token)
    return None


def ensure_tunnel(interface: str, auto_up: bool, strict: bool, max_handshake_age: int) -> None:
    """Убеждается, что интерфейс существует; при strict — требует и свежий handshake."""
    if _iface_exists(interface):
        ts = _last_handshake(interface)
        if ts is None:
            log.warning("Не удалось получить handshake для %s (нет утилиты wg или прав)", interface)
        elif ts == 0:
            log.warning("Туннель %s ни разу не выполнял handshake — возможно, peer недоступен", interface)
        else:
            age = time.time() - ts
            if age > max_handshake_age:
                # Не фатально: handshake обновляется только при трафике.
                log.warning(
                    "Последний handshake %s был %.0f сек назад (> %s) — туннель простаивал, это нормально",
                    interface, age, max_handshake_age,
                )
            else:
                log.info("Туннель %s активен (handshake %.0f сек назад)", interface, age)
        return

    if auto_up:
        log.info("Интерфейс %s отсутствует, пробую wg-quick up %s", interface, interface)
        code, out = _run(["wg-quick", "up", interface])
        if code == 0 and _iface_exists(interface):
            log.info("Туннель %s поднят", interface)
            return
        log.error("wg-quick up %s не удался: %s", interface, out)

    if strict:
        raise WireguardError(
            f"WireGuard-интерфейс {interface} недоступен (strict = true): "
            "скачивание отменено, чтобы не светить внешний IP"
        )
    log.warning(
        "Интерфейс %s недоступен — продолжаю БЕЗ привязки к туннелю (strict=false)", interface
    )


class _DeviceBindAdapter(HTTPAdapter):
    """HTTPAdapter, привязывающий сокеты к сетевому интерфейсу (SO_BINDTODEVICE)."""

    def __init__(self, interface: str, **kwargs):
        self._device = interface.encode() + b"\0"
        super().__init__(**kwargs)

    def init_poolmanager(self, *args, **kwargs):
        base = [(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)]
        kwargs["socket_options"] = base + [
            (socket.SOL_SOCKET, socket.SO_BINDTODEVICE, self._device)
        ]
        return super().init_poolmanager(*args, **kwargs)


def device_bind_supported(interface: str) -> bool:
    """Проверяет, что SO_BINDTODEVICE разрешён (нужны root/CAP_NET_RAW)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BINDTODEVICE, interface.encode() + b"\0")
        finally:
            s.close()
        return True
    except (OSError, AttributeError):
        return False


def bind_session(session: requests.Session, interface: str) -> bool:
    """Привязывает все HTTP-соединения сессии к интерфейсу. False — если не удалось."""
    if not device_bind_supported(interface):
        log.warning(
            "SO_BINDTODEVICE недоступен (нужен root/CAP_NET_RAW) — привязка к %s отключена",
            interface,
        )
        return False
    adapter = _DeviceBindAdapter(interface)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    log.info("HTTP-трафик привязан к интерфейсу %s", interface)
    return True
