"""Парсер правил Snort/Suricata.

Устойчив к комментариям, пустым строкам, CRLF, многострочным правилам,
экранированным кавычкам внутри content и хвостовым комментариям.
Правило заканчивается закрывающей скобкой блока опций `)` вне строковых
литералов (в реальных файлах snort.org/suricata строка заканчивается на `)`,
иногда за ней стоит `;` или комментарий — они отбрасываются).
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field

# Действия, с которых может начинаться правило (Snort 2/3 и Suricata).
ACTION_RE = re.compile(r"^(alert|block|drop|log|pass|reject|sdrop)\b")
SID_RE = re.compile(r"(?:^|;)\s*sid\s*:\s*(\d+)\s*;", re.IGNORECASE)
REV_RE = re.compile(r"(?:^|;)\s*rev\s*:\s*(\d+)\s*;", re.IGNORECASE)
MSG_RE = re.compile(r'\bmsg\s*:\s*"((?:[^"\\]|\\.)*)"', re.IGNORECASE)

TERMINATOR = ")"


@dataclass
class Rule:
    """Одно разобранное правило."""

    raw: str
    normalized: str
    digest: str
    sid: int | None
    rev: int | None
    msg: str
    action: str
    origin: str = ""  # имя источника (snort-registered, snort-community, cleardmr, ...)
    file: str = ""  # путь/метка файла, из которого взято
    final_sid: int | None = None
    flags: set[str] = field(default_factory=set)

    @property
    def effective_sid(self) -> int | None:
        return self.final_sid if self.final_sid is not None else self.sid


@dataclass
class ParseResult:
    rules: list[Rule]
    warnings: list[str]  # строки, которые не похожи на правило/комментарий


def scan_rule_texts(text: str) -> tuple[list[str], list[str]]:
    """Разбивает текст файла на тексты правил и предупреждения.

    Правило начинается с ключевого слова действия и заканчивается `)`
    вне строковых литералов (кавычки с учётом экранирования \").
    """
    rules: list[str] = []
    warnings: list[str] = []

    buf: list[str] = []
    in_rule = False
    in_quote = False
    escaped = False

    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not in_rule:
            if not stripped or stripped.startswith("#"):
                continue
            if not ACTION_RE.match(stripped):
                warnings.append(f"строка {lineno}: не правило и не комментарий: {stripped[:120]}")
                continue
            # новая строка правила (может быть однострочным или многострочным)
            in_rule = True
            buf = [line]
            in_quote = False
            escaped = False
        else:
            buf.append(line)

        # сканируем текущую строку — включая первую строку правила
        i = 0
        while i < len(line):
            ch = line[i]
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_quote = not in_quote
            elif ch == ")" and not in_quote:
                # конец правила: обрезаем хвост (`;`, комментарий)
                buf[-1] = line[: i + 1]
                rules.append("\n".join(buf))
                buf = []
                in_rule = False
                break
            i += 1

    if in_rule and buf:
        warnings.append("незавершённое правило в конце файла: " + " ".join(buf[0].split())[:120])
    return rules, warnings


def normalize_rule(rule_text: str) -> str:
    """Нормализация для сравнения: хвост после закрывающей `)` отбрасывается,
    пробельные последовательности вне кавычек схлопываются в один пробел."""
    end = -1
    in_quote = False
    escaped = False
    for i, ch in enumerate(rule_text):
        if escaped:
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch == '"':
            in_quote = not in_quote
        elif ch == ")" and not in_quote:
            end = i
            break
    if end != -1:
        rule_text = rule_text[: end + 1]
    out: list[str] = []
    in_quote = False
    escaped = False
    space_run = False
    suppress_space = False
    for ch in rule_text:
        if escaped:
            out.append(ch)
            escaped = False
            suppress_space = False
            continue
        if ch == "\\":
            out.append(ch)
            escaped = True
            suppress_space = False
            continue
        if ch == '"':
            in_quote = not in_quote
            out.append(ch)
            space_run = False
            suppress_space = False
            continue
        if not in_quote and ch.isspace():
            if not space_run and not suppress_space:
                out.append(" ")
                space_run = True
            continue
        if not in_quote and ch in "();:":
            # пробелы вокруг синтаксических символов не информативны
            # (разные вендоры форматируют `sid:1; rev:2;` по-разному)
            while out and out[-1] == " ":
                out.pop()
            out.append(ch)
            space_run = False
            suppress_space = True
            continue
        space_run = False
        suppress_space = False
        out.append(ch)
    return "".join(out).strip()


def parse_rules(text: str, origin: str = "", file: str = "") -> ParseResult:
    """Разбирает текст файла правил в список Rule."""
    texts, warnings = scan_rule_texts(text)
    rules: list[Rule] = []
    for t in texts:
        normalized = normalize_rule(t)
        sid_m = SID_RE.search(normalized)
        rev_m = REV_RE.search(normalized)
        msg_m = MSG_RE.search(normalized)
        action = t.lstrip().split(None, 1)[0] if t.lstrip() else ""
        rules.append(
            Rule(
                raw=t,
                normalized=normalized,
                digest=hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
                sid=int(sid_m.group(1)) if sid_m else None,
                rev=int(rev_m.group(1)) if rev_m else None,
                msg=msg_m.group(1) if msg_m else "",
                action=action,
                origin=origin,
                file=file,
            )
        )
    return ParseResult(rules=rules, warnings=warnings)
