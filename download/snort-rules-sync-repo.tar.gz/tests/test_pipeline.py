"""Тесты конвейера дедупликации и ресолва пересечений SID."""

import pytest

from snort_rules_sync.config import CollisionsConfig
from snort_rules_sync.parser import parse_rules
from snort_rules_sync.pipeline import PipelineError, SourceInput, build_ruleset

from conftest import C_OLDER, C_OTHER, C_SAME, R_A1, R_A2, R_A3, R_COL


def _mk(text: str, name: str, priority: int):
    return SourceInput(name=name, priority=priority, rules=parse_rules(text, origin=name).rules)


def _cfg(**kw) -> CollisionsConfig:
    return CollisionsConfig(**kw)


def test_identical_rules_deduplicated_across_sources():
    a = _mk(R_A1 + "\n", "snort-community", 2)
    b = _mk(R_A1 + "\n" + R_A2 + "\n", "snort-registered", 1)
    res = build_ruleset([a, b], _cfg())
    assert len(res.rules) == 2
    assert res.stats.dropped_identical
    assert res.stats.dropped_identical[0]["kept_by"] == "snort-registered"


def test_internal_sid_collision_renumbered():
    # два РАЗНЫХ правила с одним SID в разных источниках
    other_same_sid = R_A2.replace("sid:2000002", "sid:2000001")
    a = _mk(R_A1 + "\n" + other_same_sid + "\n", "src-b", 2)
    b = _mk(R_A1 + "\n" + R_A2 + "\n", "src-a", 1)
    res = build_ruleset([a, b], _cfg())
    sids = sorted(r.effective_sid for r in res.rules)
    assert len(sids) == len(set(sids)), "все итоговые SID уникальны"
    assert 2000001 in sids and 2000002 in sids
    # проигравший получил SID из локального диапазона
    assert any(1_000_000 <= r.effective_sid < 2_000_000 for r in res.rules)
    assert len(res.stats.renumbered) == 1
    assert res.stats.renumbered[0]["old_sid"] == 2000001


def test_internal_collision_strategy_drop():
    other_same_sid = R_A2.replace("sid:2000002", "sid:2000001")
    a = _mk(R_A1 + "\n" + other_same_sid + "\n", "src-b", 2)
    b = _mk(R_A1 + "\n" + R_A2 + "\n", "src-a", 1)
    res = build_ruleset([a, b], _cfg(strategy="drop"))
    assert len(res.rules) == 2
    assert res.stats.renumbered == []
    assert len(res.stats.dropped_collisions) == 1


def test_occupied_identical_rule_dropped():
    snort = _mk(R_A1 + "\n" + R_A2 + "\n", "snort-registered", 1)
    cleardmr = _mk(C_SAME + "\n" + C_OTHER + "\n", "cleardmr", 0)
    occupied = {r.sid: r for r in cleardmr.rules}
    res = build_ruleset([snort], _cfg(), occupied=occupied)
    # 2000001 идентичен существующему -> удалён; 2000002 в cleardmr занят ДРУГИМ правилом
    assert len(res.rules) == 1
    assert res.rules[0].sid == 2000002
    assert res.rules[0].final_sid != 2000002  # перенумерован
    assert any(d["sid"] == 2000001 for d in res.stats.dropped_identical)


def test_occupied_same_msg_newer_rev_upgraded():
    snort = _mk(C_OLDER.replace("rev:2", "rev:5") + "\n", "snort-registered", 1)
    cleardmr = _mk(C_OLDER + "\n", "cleardmr", 0)
    occupied = {r.sid: r for r in cleardmr.rules}
    res = build_ruleset([snort], _cfg(), occupied=occupied)
    assert len(res.rules) == 1
    assert res.rules[0].final_sid == res.rules[0].sid  # SID сохранён
    assert "upgrade" in res.rules[0].flags
    assert res.stats.upgraded and res.stats.upgraded[0]["new_rev"] == 5


def test_occupied_same_msg_prefer_cleardmr():
    snort = _mk(C_OLDER.replace("rev:2", "rev:5") + "\n", "snort-registered", 1)
    cleardmr = _mk(C_OLDER + "\n", "cleardmr", 0)
    occupied = {r.sid: r for r in cleardmr.rules}
    res = build_ruleset(
        [snort], _cfg(strategy="drop", same_msg_newer_rev="prefer_cleardmr"), occupied=occupied
    )
    assert len(res.rules) == 0
    assert len(res.stats.dropped_collisions) == 1


def test_renumber_pool_skips_used_sids():
    # правило snort с SID 1000000 (занят в Clear NDR ДРУГИМ правилом "used1")
    snort_rule = 'drop tcp $HOME_NET any -> 10.0.0.1 445 (msg:"SNRT New rule"; content:"n"; sid:1000000; rev:1;)'
    snort = _mk(snort_rule + "\n", "snort-registered", 1)
    occ_rules = parse_rules(
        'alert tcp any any -> any any (msg:"used1"; sid:1000000; rev:1;)\n'
        'alert tcp any any -> any any (msg:"used2"; sid:1000001; rev:1;)\n'
    ).rules
    occupied = {r.sid: r for r in occ_rules}
    res = build_ruleset([snort], _cfg(), occupied=occupied)
    # 1000000 и 1000001 заняты -> свободен 1000002
    assert res.rules[0].final_sid == 1000002


def test_superseded_rev_within_sources():
    a = _mk(R_A1 + "\n", "src-a", 1)
    b = _mk(R_A1.replace("rev:3", "rev:2") + "\n", "src-b", 2)
    res = build_ruleset([a, b], _cfg())
    assert len(res.rules) == 1
    assert res.rules[0].rev == 3
    assert len(res.stats.dropped_superseded) == 1


def test_no_sid_rules_skipped():
    a = _mk('alert tcp any any -> any any (msg:"no sid"; content:"x";)\n', "src-a", 1)
    res = build_ruleset([a], _cfg())
    assert res.rules == []


def test_pool_exhaustion_raises():
    tiny = _cfg(range_start=1000000, range_end=1000000)
    rules = "\n".join(
        f'alert tcp any any -> any any (msg:"m{i}"; sid:{1000000}; rev:{i};)' for i in range(3)
    )
    a = _mk(rules + "\n", "src-a", 1)
    # три разных msg на одном SID: один остаётся, двое требуют перенумерации, а место одно
    with pytest.raises(PipelineError):
        build_ruleset([a], tiny)


def test_deterministic_output():
    rules_text = R_A1 + "\n" + R_A2 + "\n" + R_A3 + "\n" + R_COL + "\n"
    occ = parse_rules(C_SAME + "\n" + C_OTHER + "\n").rules
    occupied = {r.sid: r for r in occ}
    r1 = build_ruleset([_mk(rules_text, "snort", 1)], _cfg(), occupied=occupied)
    r2 = build_ruleset([_mk(rules_text, "snort", 1)], _cfg(), occupied=occupied)
    assert [r.final_sid for r in r1.rules] == [r.final_sid for r in r2.rules]


def test_no_collisions_with_occupied_after_renumber():
    snort = _mk(R_A1 + "\n" + R_A2 + "\n" + R_A3 + "\n" + R_COL + "\n", "snort", 1)
    occ_rules = parse_rules(
        C_SAME + "\n" + C_OTHER + "\n" +
        'alert tcp any any -> any any (msg:"z1"; sid:1000000; rev:1;)\n' +
        'alert tcp any any -> any any (msg:"z2"; sid:1000001; rev:1;)\n'
    ).rules
    occupied = {r.sid: r for r in occ_rules}
    res = build_ruleset([snort], _cfg(), occupied=occupied)
    final_sids = [r.effective_sid for r in res.rules]
    assert len(final_sids) == len(set(final_sids))
    for sid in final_sids:
        assert sid not in occupied or any(
            r.effective_sid == sid and "upgrade" in r.flags for r in res.rules
        )
