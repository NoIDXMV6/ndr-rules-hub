"""Сквозные (end-to-end) тесты: полный цикл sync с фейковыми snort.org и Scirius."""

import tarfile

import pytest

from snort_rules_sync.cli import main
from snort_rules_sync.parser import parse_rules

from conftest import C_OTHER, C_SAME, R_A1, R_A2, R_A3, R_COL


def write_config(tmp_path, workdir, snort_server, scirius_server, **overrides) -> str:
    push = overrides.get("push", "true")
    include_rules = overrides.get("include_rules", "false")
    text = f"""
[general]
workdir = "{workdir}"

[snort]
oinkcode = "{snort_server.oinkcode}"
community_url = "{snort_server.base}/downloads/community/community-rules.tar.gz"
reg_rules_base = "{snort_server.base}/reg-rules"
downloads_page = "{snort_server.base}/downloads"
retries = 1
timeout = 10

[wireguard]
enabled = false

[cleardmr]
enabled = true
url = "{scirius_server.base}"
verify_tls = false
token = "{scirius_server.TOKEN}"
username = "{scirius_server.USER}"
password = "{scirius_server.PASSWORD}"
ruleset = "default"
source_name = "snort-sync"
pull_mode = "auto"
push = {push}
include_rules = {include_rules}
"""
    p = tmp_path / "config.toml"
    p.write_text(text, encoding="utf-8")
    return str(p)


def test_full_sync_with_push(tmp_path, snort_server, scirius_server):
    cfg_path = write_config(tmp_path, tmp_path / "workdir", snort_server, scirius_server)
    rc = main(["sync", "--config", cfg_path])
    assert rc == 0

    out = tmp_path / "workdir" / "dist"

    # 1. финальный файл существует и корректен
    final_text = (out / "final.rules").read_text(encoding="utf-8")
    final_rules = parse_rules(final_text).rules
    assert len(final_rules) == 3  # R_A1(дубль cleardmr удалён), R_A2→renumber, R_A3, R_COL
    sids = [r.effective_sid for r in final_rules]
    assert len(sids) == len(set(sids)), "SID уникальны"

    # 2. R_A1 был идентичен правилу в Clear NDR -> удалён
    msgs = {r.msg for r in final_rules}
    assert "SNRT Test alpha" not in msgs

    # 3. R_A2 пересёкся с C_OTHER (sid 2000002) -> перенумерован в локальный диапазон
    r_a2 = next(r for r in final_rules if r.msg == "SNRT Test beta")
    assert r_a2.sid != 2000002
    assert 1_000_000 <= r_a2.sid < 2_000_000
    assert f"# sid перенумерован: 2000002 -> {r_a2.sid}" in (out / "final.rules").read_text(encoding="utf-8")

    # 4. манифест и отчёт созданы
    import json

    manifest = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["total_input"] == 7  # 3 из community + 4 из снапшота
    assert manifest["total_output"] == len(final_rules)
    assert (out / "report.md").is_file()

    # 5. tarball в формате Scirius: rules/snort-sync.rules
    with tarfile.open(out / "snort-sync.tar.gz") as tar:
        names = tar.getnames()
    assert "rules/snort-sync.rules" in names

    # 6. push прошёл: источник создан, файл загружен, ruleset обновлён
    assert any(s["name"] == "snort-sync" for s in scirius_server.sources)
    assert scirius_server.uploaded
    assert scirius_server.updates_triggered == [1]
    # источник привязан к ruleset
    assert scirius_server.sources[0]["pk"] in scirius_server.rulesets[0]["sources"]


def test_sync_without_push(tmp_path, snort_server, scirius_server):
    cfg_path = write_config(
        tmp_path, tmp_path / "w2", snort_server, scirius_server, push="false"
    )
    rc = main(["sync", "--config", cfg_path])
    assert rc == 0
    assert scirius_server.uploaded == []
    assert scirius_server.updates_triggered == []


def test_sync_pull_mode_off(tmp_path, snort_server, scirius_server):
    cfg_path = write_config(tmp_path, tmp_path / "w3", snort_server, scirius_server)
    # добавим pull_mode = "off" через строку
    text = open(cfg_path, encoding="utf-8").read().replace('pull_mode = "auto"', 'pull_mode = "off"')
    open(cfg_path, "w", encoding="utf-8").write(text)
    rc = main(["sync", "--config", cfg_path])
    assert rc == 0
    out = tmp_path / "w3" / "dist"
    final_rules = parse_rules((out / "final.rules").read_text(encoding="utf-8")).rules
    # без cleardmr-occupancy: R_A1 остаётся (дублей внутри архивов нет,
    # community.rules и rules/snort3-community.rules идентичны -> дедуп внутри)
    msgs = {r.msg for r in final_rules}
    assert "SNRT Test alpha" in msgs
    assert len({r.effective_sid for r in final_rules}) == len(final_rules)


def test_sync_include_rules_consolidated(tmp_path, snort_server, scirius_server):
    cfg_path = write_config(
        tmp_path, tmp_path / "w4", snort_server, scirius_server,
        push="false", include_rules="true",
    )
    rc = main(["sync", "--config", cfg_path])
    assert rc == 0
    out = tmp_path / "w4" / "dist"
    final_rules = parse_rules((out / "final.rules").read_text(encoding="utf-8")).rules
    msgs = {r.msg for r in final_rules}
    # правила Clear NDR вошли в файл, дубль SNRT Test alpha удалён
    assert "PT Existing rule" in msgs
    sids = [r.effective_sid for r in final_rules]
    assert len(sids) == len(set(sids))


def test_download_command(tmp_path, snort_server, scirius_server):
    cfg_path = write_config(tmp_path, tmp_path / "w5", snort_server, scirius_server)
    rc = main(["download", "--config", cfg_path])
    assert rc == 0
    arch = tmp_path / "w5" / "archives"
    assert list(arch.glob("community-rules-*.tar.gz"))
    assert list(arch.glob("snortrules-snapshot-*-*.tar.gz"))


def test_build_command_uses_cache(tmp_path, snort_server, scirius_server):
    cfg_path = write_config(tmp_path, tmp_path / "w6", snort_server, scirius_server, push="false")
    assert main(["download", "--config", cfg_path]) == 0
    assert main(["build", "--config", cfg_path]) == 0
    out = tmp_path / "w6" / "dist"
    assert (out / "final.rules").is_file()
    assert (out / "snort-sync.tar.gz").is_file()


def test_check_command(tmp_path, snort_server, scirius_server, capsys):
    cfg_path = write_config(tmp_path, tmp_path / "w7", snort_server, scirius_server)
    rc = main(["check", "--config", cfg_path])
    assert rc == 0
    captured = capsys.readouterr()
    assert "snort.org: OK" in captured.out
    assert "Clear NDR" in captured.out
