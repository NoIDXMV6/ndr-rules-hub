"""Безопасная распаковка tar-архивов и выбор файлов правил по glob-шаблонам."""

from __future__ import annotations

import fnmatch
import posixpath
import tarfile
from pathlib import Path


class ArchiveError(Exception):
    pass


def extract_tarball(archive: Path, dest: Path) -> Path:
    """Распаковывает tar.gz в dest с защитой от path traversal.

    Возвращает каталог, куда распаковано. Символьные/жёсткие ссылки
    и устройства пропускаются.
    """
    dest.mkdir(parents=True, exist_ok=True)
    dest = dest.resolve()
    try:
        with tarfile.open(archive, "r:*") as tar:
            for member in tar.getmembers():
                if not (member.isfile() or member.isdir()):
                    continue  # symlinks/hardlinks/devices не распаковываем
                target = posixpath.normpath(member.name)
                if target.startswith("/") or target.startswith("..") or posixpath.isabs(target):
                    raise ArchiveError(f"Небезопасный путь в архиве: {member.name!r}")
                full = (dest / target).resolve()
                if dest != full and dest not in full.parents:
                    raise ArchiveError(f"Path traversal в архиве: {member.name!r}")
                tar.extract(member, dest, filter="data" if hasattr(tarfile, "data_filter") else None)
    except tarfile.TarError as exc:
        raise ArchiveError(f"Не удалось распаковать {archive}: {exc}") from exc
    return dest


def _match(rel: str, patterns: list[str]) -> bool:
    """Glob-сопоставление: ** проходит по любому числу каталогов."""
    for pat in patterns:
        if "**" in pat:
            head, _, tail = pat.partition("**/")
            parts = rel.split("/")
            # префикс каталогов, затем сопоставление хвоста с любой позиции
            tail_variants = ["/".join(parts[i:]) for i in range(len(parts) + 1)]
            if any(fnmatch.fnmatch(v, tail) for v in tail_variants) and (
                not head or rel.startswith(head)
            ):
                return True
        elif fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(posixpath.basename(rel), pat):
            return True
    return False


def collect_rule_files(root: Path, include: list[str], exclude: list[str]) -> list[Path]:
    """Возвращает отсортированный список файлов правил по шаблонам include/exclude."""
    root = Path(root)
    if not root.is_dir():
        raise ArchiveError(f"Каталог не найден: {root}")
    result: list[Path] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if not _match(rel, include):
            continue
        if _match(rel, exclude):
            continue
        result.append(path)
    return result


def read_text_safe(path: Path) -> str:
    """Читает файл правил с устойчивостью к чужой кодировке."""
    data = path.read_bytes()
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="replace")
