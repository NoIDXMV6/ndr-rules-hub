"""Тесты клиента Clear NDR (Scirius): token/сессия, pull, push."""

import pytest

from snort_rules_sync.cleardmr import SciriusAuthError, SciriusClient, SciriusError
from snort_rules_sync.config import ClearNDRConfig
from snort_rules_sync.parser import parse_rules

from conftest import C_OTHER, C_SAME


@pytest.fixture()
def cfg(scirius_server) -> ClearNDRConfig:
    return ClearNDRConfig(
        enabled=True,
        url=scirius_server.base,
        verify_tls=False,
        token=scirius_server.TOKEN,
        username=scirius_server.USER,
        password=scirius_server.PASSWORD,
        ruleset="default",
    )


@pytest.fixture()
def client(cfg):
    return SciriusClient(cfg)


def test_token_auth_required(scirius_server):
    bad = SciriusClient(ClearNDRConfig(url=scirius_server.base, token="invalid"))
    with pytest.raises(SciriusAuthError):
        bad.rest("GET", "/rest/rules/ruleset/")


def test_find_ruleset_and_resolve_pk(client):
    assert client.resolve_ruleset_pk("default") == 1
    with pytest.raises(SciriusError, match="не найден"):
        client.resolve_ruleset_pk("нету-такого")


def test_pull_via_export(client, scirius_server):
    text, mode = client.pull_rules()
    assert mode == "export"
    rules = parse_rules(text).rules
    sids = {r.sid for r in rules}
    assert 2000001 in sids and 2000002 in sids


def test_pull_via_rest_fallback(client, scirius_server):
    # export недоступен (нет сессии) -> авто-фолбэк на REST
    client.cfg.username = ""
    client.cfg.password = ""
    scirius_server.add_rules_via_rest(50, 9, C_SAME + "\n" + C_OTHER + "\n")
    scirius_server.rulesets[0]["categories"] = [50]
    text, mode = client.pull_rules()
    assert mode == "rest"
    sids = {r.sid for r in parse_rules(text).rules}
    assert 2000001 in sids


def test_pull_from_dir(tmp_path):
    d = tmp_path / "exports"
    d.mkdir()
    (d / "ruleset.rules").write_text(C_SAME + "\n" + C_OTHER + "\n")
    cfg = ClearNDRConfig(url="https://x", pull_mode="dir", export_dir=str(d))
    client = SciriusClient(cfg)
    text = client.pull_rules_from_dir()
    assert len(parse_rules(text).rules) == 2


def test_push_full_flow(client, scirius_server, tmp_path):
    tarball = tmp_path / "snort-sync.tar.gz"
    tarball.write_bytes(b"placeholder")
    # подменим содержимое на валидный tar.gz через report.build_tarball
    from snort_rules_sync.report import build_tarball

    build_tarball(
        'alert tcp any any -> any any (msg:"new rule"; sid:2000099; rev:1;)\n',
        "snort-sync",
        tarball,
    )
    summary = client.push(tarball, "default", "snort-sync", do_update=True)
    assert summary["ruleset_pk"] == 1
    assert summary["source_pk"] >= 10
    assert summary["updated"] is True
    # источник создан один раз, повторный push не создаёт дубликат
    summary2 = client.push(tarball, "default", "snort-sync", do_update=False)
    assert summary2["source_pk"] == summary["source_pk"]
    assert len(scirius_server.uploaded) == 2


def test_web_session_login_failure(scirius_server):
    cfg = ClearNDRConfig(url=scirius_server.base, token="x",
                         username=scirius_server.USER, password="wrong")
    client = SciriusClient(cfg)
    with pytest.raises(SciriusAuthError):
        client.web_session()


def test_upload_source_file(client, scirius_server, tmp_path):
    from snort_rules_sync.report import build_tarball

    tarball = build_tarball('alert ip any any -> any any (msg:"u"; sid:1; rev:1;)\n',
                            "snort-sync", tmp_path / "u.tar.gz")
    src = client.ensure_source("snort-sync")
    client.upload_source_file(int(src["pk"]), tarball)
    assert scirius_server.uploaded, "сервер получил файл"


def test_attach_source_to_ruleset(client, scirius_server):
    src = client.ensure_source("snort-sync")
    pk = int(src["pk"])
    scirius_server.categories.append({"pk": 77, "name": "snort-sync", "source": pk})
    attached = client.attach_source_to_ruleset(1, pk)
    assert attached is True
    detail = client.rest("GET", "/rest/rules/ruleset/1/").json()
    assert pk in detail["sources"]
    assert 77 in detail["categories"]
    # повторная привязка — no-op
    assert client.attach_source_to_ruleset(1, pk) is False
