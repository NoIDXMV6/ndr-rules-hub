"""Клиент snort.org: скачивание community-rules и registered-снапшота.

* community-rules.tar.gz скачивается без авторизации;
* snortrules-snapshot-XXXXX.tar.gz требует oinkcode активного (registered) аккаунта:
  https://www.snort.org/reg-rules/snortrules-snapshot-XXXXX.tar.gz/<oinkcode>
* версия снапшота определяется автоматически со страницы https://www.snort.org/downloads
  (или задаётся вручную в конфиге);
* архивы кэшируются в workdir/archives с датой в имени: повторный запуск в тот же
  день не скачивает заново; при ошибке сети можно откатиться на свежий кэш.
"""

from __future__ import annotations

import datetime as dt
import logging
import re
import time
from pathlib import Path

import requests

from .config import SnortConfig

log = logging.getLogger("snort")

SNAPSHOT_RE = re.compile(r"snortrules-snapshot-(\d{4,6})\.tar\.gz")
GZIP_MAGIC = b"\x1f\x8b"


class SnortError(Exception):
    pass


class SnortClient:
    def __init__(self, cfg: SnortConfig, session: requests.Session):
        self.cfg = cfg
        self.session = session

    # ---------------- версия снапшота ----------------

    def detect_snapshot_version(self) -> str:
        """Определяет актуальную версию снапшота по странице downloads."""
        resp = self.session.get(
            self.cfg.downloads_page,
            headers={"User-Agent": self.cfg.user_agent},
            timeout=30,
        )
        resp.raise_for_status()
        versions = [int(v) for v in SNAPSHOT_RE.findall(resp.text)]
        if not versions:
            raise SnortError(
                f"На странице {self.cfg.downloads_page} не найдено ни одной версии "
                "snortrules-snapshot-*.tar.gz — задайте snort.snapshot_version вручную"
            )
        return str(max(versions))

    # ---------------- скачивание ----------------

    def _download(self, url: str, dest: Path) -> Path:
        headers = {"User-Agent": self.cfg.user_agent}
        last_error: Exception | None = None
        for attempt in range(1, self.cfg.retries + 2):
            try:
                log.info("Скачиваю %s (попытка %d)", url, attempt)
                with self.session.get(
                    url, headers=headers, timeout=self.cfg.timeout, stream=True
                ) as resp:
                    if resp.status_code in (403, 404) and "reg-rules" in url:
                        raise SnortError(
                            f"HTTP {resp.status_code} от snort.org: проверьте oinkcode и статус аккаунта "
                            "(registered-аккаунт должен быть активирован, oinkcode свежий)"
                        )
                    if resp.status_code == 429:
                        raise SnortError(
                            "snort.org ограничил частоту скачивания (429). "
                            "Правила с snort.org можно скачивать не чаще раза в 15 минут"
                        )
                    resp.raise_for_status()
                    tmp = dest.with_suffix(dest.suffix + ".part")
                    size = 0
                    with open(tmp, "wb") as fh:
                        for chunk in resp.iter_content(chunk_size=1 << 16):
                            if chunk:
                                fh.write(chunk)
                                size += len(chunk)
                    with open(tmp, "rb") as fh:
                        magic = fh.read(2)
                    if magic != GZIP_MAGIC:
                        raise SnortError(
                            f"Ответ не является gzip-архивом ({size} байт) — вероятно, "
                            f"страница ошибки: {url}"
                        )
                    tmp.replace(dest)
                    log.info("Сохранено: %s (%d байт)", dest, size)
                    return dest
            except (requests.RequestException, SnortError) as exc:
                last_error = exc
                if isinstance(exc, SnortError) and (
                    "429" in str(exc) or "oinkcode" in str(exc)
                ):
                    break  # повторять бессмысленно
                time.sleep(3 * attempt)
        raise SnortError(f"Не удалось скачать {url}: {last_error}")

    def _cache_fallback(self, pattern: str) -> Path | None:
        """Самый свежий архив в кэше не старше max_cache_age_days."""
        files = sorted(self.cfg_archives().glob(pattern))
        if not files:
            return None
        newest = files[-1]
        m = re.search(r"(\d{8})", newest.name)
        if not m:
            return None
        try:
            age = dt.date.today() - dt.datetime.strptime(m.group(1), "%Y%m%d").date()
        except ValueError:
            return None
        if age.days > self.cfg.max_cache_age_days:
            return None
        return newest

    # ---------------- публичное API ----------------

    def get_community_rules(self, archives_dir: Path, force: bool = False) -> Path:
        today = dt.date.today().strftime("%Y%m%d")
        dest = archives_dir / f"community-rules-{today}.tar.gz"
        if dest.is_file() and not force:
            log.info("Кэш community-rules за сегодня уже есть: %s", dest.name)
            return dest
        try:
            return self._download(self.cfg.community_url, dest)
        except SnortError:
            if self.cfg.use_cache_on_error:
                cached = self._cache_fallback_in(archives_dir, "community-rules-*.tar.gz")
                if cached:
                    log.warning("Скачивание не удалось, использую кэш %s", cached.name)
                    return cached
            raise

    def get_registered_rules(self, archives_dir: Path, force: bool = False) -> Path | None:
        if not self.cfg.oinkcode:
            log.warning(
                "snort.oinkcode не задан — registered-снапшот пропущен "
                "(будут использованы только community rules)"
            )
            return None
        version = self.cfg.snapshot_version.strip()
        if not version:
            version = self.detect_snapshot_version()
            log.info("Определена актуальная версия снапшота: %s", version)
        else:
            log.info("Использую заданную версию снапшота: %s", version)

        today = dt.date.today().strftime("%Y%m%d")
        dest = archives_dir / f"snortrules-snapshot-{version}-{today}.tar.gz"
        if dest.is_file() and not force:
            log.info("Кэш снапшота за сегодня уже есть: %s", dest.name)
            return dest

        url = f"{self.cfg.reg_rules_base}/snortrules-snapshot-{version}.tar.gz/{self.cfg.oinkcode}"
        try:
            return self._download(url, dest)
        except SnortError:
            if self.cfg.use_cache_on_error:
                cached = self._cache_fallback_in(
                    archives_dir, f"snortrules-snapshot-{version}-*.tar.gz"
                )
                if cached:
                    log.warning("Скачивание не удалось, использую кэш %s", cached.name)
                    return cached
            raise

    def _cache_fallback_in(self, archives_dir: Path, pattern: str) -> Path | None:
        files = sorted(archives_dir.glob(pattern))
        if not files:
            return None
        newest = files[-1]
        m = re.search(r"(\d{8})", newest.name)
        if not m:
            return None
        try:
            age = dt.date.today() - dt.datetime.strptime(m.group(1), "%Y%m%d").date()
        except ValueError:
            return None
        if age.days > self.cfg.max_cache_age_days:
            return None
        return newest
