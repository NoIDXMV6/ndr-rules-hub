"""Загрузка и валидация конфигурации snort-rules-sync (TOML + переменные окружения)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:  # Python 3.11+
    import tomllib  # type: ignore[import-not-found]
except ImportError:  # Python 3.10
    import tomli as tomllib  # type: ignore[no-redef]

STRATEGIES = ("renumber", "drop")
PULL_MODES = ("auto", "export", "rest", "dir", "off")
NEWER_REV_MODES = ("upgrade", "prefer_cleardmr")


class ConfigError(Exception):
    """Ошибка конфигурации (неверное значение, плохой файл и т.п.)."""


@dataclass
class GeneralConfig:
    workdir: Path = Path("/var/lib/snort-rules-sync")
    log_level: str = "info"


@dataclass
class SnortConfig:
    oinkcode: str = ""
    user_agent: str = "snort-rules-sync/1.0"
    snapshot_version: str = ""  # пусто = автоопределение с www.snort.org/downloads
    community_url: str = (
        "https://www.snort.org/downloads/community/community-rules.tar.gz"
    )
    reg_rules_base: str = "https://www.snort.org/reg-rules"
    downloads_page: str = "https://www.snort.org/downloads"
    use_cache_on_error: bool = True
    max_cache_age_days: int = 7
    retries: int = 2
    timeout: int = 120


@dataclass
class WireguardConfig:
    enabled: bool = True
    interface: str = "wg0"
    auto_up: bool = False
    strict: bool = False
    max_handshake_age: int = 600


@dataclass
class CollisionsConfig:
    strategy: str = "renumber"  # renumber | drop
    range_start: int = 1_000_000
    range_end: int = 1_999_999
    same_msg_newer_rev: str = "upgrade"  # upgrade | prefer_cleardmr


@dataclass
class IncludeConfig:
    rules_globs: list[str] = field(
        default_factory=lambda: ["**/*.rules"]
    )
    exclude_globs: list[str] = field(
        default_factory=lambda: [
            "*-deleted.rules",
            "snort3-deleted.rules",
            "decoder.rules",
            "preprocessor.rules",
            "snort3-appid-framework.rules",
        ]
    )


@dataclass
class ClearNDRConfig:
    enabled: bool = False     # в config.example.toml включено явно
    url: str = ""
    verify_tls: bool = False
    token: str = ""          # для /rest/* (DRF TokenAuthentication)
    username: str = ""       # сессия — для функциональных view (export, ruleset update)
    password: str = ""
    ruleset: str = "default"
    source_name: str = "snort-sync"
    pull_mode: str = "auto"  # auto | export | rest | dir | off
    export_dir: str = ""     # каталог с ручными экспортами (*.rules / *.tgz) для pull_mode=dir
    include_rules: bool = False  # включать правила Clear NDR в финальный файл
    push: bool = False       # автоматически импортировать финальный файл


@dataclass
class AppConfig:
    general: GeneralConfig = field(default_factory=GeneralConfig)
    snort: SnortConfig = field(default_factory=SnortConfig)
    wireguard: WireguardConfig = field(default_factory=WireguardConfig)
    collisions: CollisionsConfig = field(default_factory=CollisionsConfig)
    include: IncludeConfig = field(default_factory=IncludeConfig)
    cleardmr: ClearNDRConfig = field(default_factory=ClearNDRConfig)

    def output_dir(self) -> Path:
        p = Path(self.general.workdir) / "dist"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def archives_dir(self) -> Path:
        p = Path(self.general.workdir) / "archives"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def extract_dir(self) -> Path:
        p = Path(self.general.workdir) / "extracted"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def pull_dir(self) -> Path:
        p = Path(self.general.workdir) / "pull"
        p.mkdir(parents=True, exist_ok=True)
        return p


def _as_bool(value: object, key: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.lower() in ("true", "false", "1", "0", "yes", "no"):
        return value.lower() in ("true", "1", "yes")
    raise ConfigError(f"Ожидался boolean для '{key}', получено: {value!r}")


def _apply(dataclass_obj: object, section: dict, prefix: str) -> None:
    """Накатывает значения секции TOML на существующий dataclass с проверкой имён полей."""
    import dataclasses

    valid = {f.name for f in dataclasses.fields(dataclass_obj)}  # type: ignore[arg-type]
    for key, value in section.items():
        if key not in valid:
            raise ConfigError(
                f"Неизвестный ключ '{prefix}.{key}' в конфиге (допустимо: {', '.join(sorted(valid))})"
            )
        current = getattr(dataclass_obj, key)
        if isinstance(current, bool):
            setattr(dataclass_obj, key, _as_bool(value, f"{prefix}.{key}"))
        elif isinstance(current, int) and not isinstance(current, bool):
            setattr(dataclass_obj, key, int(value))
        elif isinstance(current, Path):
            setattr(dataclass_obj, key, Path(str(value)).expanduser())
        else:
            setattr(dataclass_obj, key, str(value) if value is not None else current)


def load_config(path: str | Path | None) -> AppConfig:
    """Читает TOML-конфиг; затем применяет переменные окружения поверх."""
    cfg = AppConfig()

    if path is not None:
        p = Path(path).expanduser()
        if not p.is_file():
            raise ConfigError(f"Файл конфигурации не найден: {p}")
        try:
            raw = tomllib.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:  # pragma: no cover - маловероятные ошибки парсера
            raise ConfigError(f"Не удалось разобрать {p}: {exc}") from exc
        sections = {
            "general": cfg.general,
            "snort": cfg.snort,
            "wireguard": cfg.wireguard,
            "collisions": cfg.collisions,
            "include": cfg.include,
            "cleardmr": cfg.cleardmr,
        }
        for name, obj in sections.items():
            section = raw.get(name)
            if section is None:
                continue
            if not isinstance(section, dict):
                raise ConfigError(f"Секция [{name}] должна быть таблицей TOML")
            _apply(obj, section, name)

    # --- Переменные окружения (секреты и пути поверх файла) ---
    env_oink = os.environ.get("SNORT_OINKCODE", "").strip()
    if env_oink:
        cfg.snort.oinkcode = env_oink

    env_token = os.environ.get("CLEARDMR_TOKEN", "").strip()
    if env_token:
        cfg.cleardmr.token = env_token

    env_pass = os.environ.get("CLEARDMR_PASSWORD", "")
    if env_pass:
        cfg.cleardmr.password = env_pass

    env_workdir = os.environ.get("SNORT_RULES_SYNC_WORKDIR", "").strip()
    if env_workdir:
        cfg.general.workdir = Path(env_workdir)

    _validate(cfg)
    return cfg


def _validate(cfg: AppConfig) -> None:
    if cfg.collisions.strategy not in STRATEGIES:
        raise ConfigError(
            f"collisions.strategy должен быть одним из {STRATEGIES}, сейчас: {cfg.collisions.strategy!r}"
        )
    if cfg.collisions.same_msg_newer_rev not in NEWER_REV_MODES:
        raise ConfigError(
            f"collisions.same_msg_newer_rev должен быть одним из {NEWER_REV_MODES}"
        )
    if cfg.collisions.range_start >= cfg.collisions.range_end:
        raise ConfigError("collisions.range_start должен быть меньше collisions.range_end")
    if cfg.collisions.range_start < 1 or cfg.collisions.range_end > 2_000_000_000:
        raise ConfigError("Диапазон ресолва SID вне допустимых пределов (1..2e9)")
    if cfg.cleardmr.pull_mode not in PULL_MODES:
        raise ConfigError(f"cleardmr.pull_mode должен быть одним из {PULL_MODES}")

    nd = cfg.cleardmr
    if nd.enabled and nd.push:
        if not nd.url:
            raise ConfigError("cleardmr.url обязателен при cleardmr.push = true")
        if not nd.token and not (nd.username and nd.password):
            raise ConfigError(
                "Для автоматического импорта нужен cleardmr.token "
                "и/или cleardmr.username + cleardmr.password "
                "(или переменные окружения CLEARDMR_TOKEN / CLEARDMR_PASSWORD)"
            )
    if nd.enabled and nd.pull_mode in ("auto", "export", "rest") and not nd.url:
        raise ConfigError(
            f"cleardmr.url обязателен при pull_mode = '{nd.pull_mode}' "
            "(или используйте pull_mode = 'dir' с cleardmr.export_dir)"
        )
    if nd.enabled and nd.pull_mode == "dir" and not nd.export_dir:
        raise ConfigError("cleardmr.export_dir обязателен при pull_mode = 'dir'")
