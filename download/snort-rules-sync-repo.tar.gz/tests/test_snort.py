"""Тесты клиента snort.org (скачивание, автоопределение версии, кэш, повторы)."""

import pytest

from snort_rules_sync.config import SnortConfig
from snort_rules_sync.snort import SnortClient, SnortError

import requests


@pytest.fixture()
def cfg(snort_server) -> SnortConfig:
    return SnortConfig(
        oinkcode=snort_server.oinkcode,
        community_url=f"{snort_server.base}/downloads/community/community-rules.tar.gz",
        reg_rules_base=f"{snort_server.base}/reg-rules",
        downloads_page=f"{snort_server.base}/downloads",
        retries=1,
        timeout=10,
    )


@pytest.fixture()
def client(cfg):
    return SnortClient(cfg, requests.Session())


def test_detect_snapshot_version(client, snort_server):
    assert client.detect_snapshot_version() == snort_server.snapshot_version


def test_download_community_and_cache(client, tmp_path, snort_server):
    p1 = client.get_community_rules(tmp_path)
    assert p1.is_file()
    # второй вызов берёт кэш (нет второго запроса)
    before = len(snort_server.requests)
    p2 = client.get_community_rules(tmp_path)
    assert p1 == p2
    assert len(snort_server.requests) == before


def test_download_registered_with_oinkcode(client, tmp_path, snort_server):
    p = client.get_registered_rules(tmp_path)
    assert p is not None
    assert snort_server.snapshot_version in p.name


def test_registered_skipped_without_oinkcode(snort_server, tmp_path, caplog):
    cfg = SnortConfig(
        community_url=f"{snort_server.base}/downloads/community/community-rules.tar.gz",
        reg_rules_base=f"{snort_server.base}/reg-rules",
        downloads_page=f"{snort_server.base}/downloads",
    )
    client = SnortClient(cfg, requests.Session())
    assert client.get_registered_rules(tmp_path) is None


def test_wrong_oinkcode_fails(snort_server, tmp_path):
    cfg = SnortConfig(
        oinkcode="WRONG",
        community_url=f"{snort_server.base}/downloads/community/community-rules.tar.gz",
        reg_rules_base=f"{snort_server.base}/reg-rules",
        downloads_page=f"{snort_server.base}/downloads",
        retries=0,
    )
    client = SnortClient(cfg, requests.Session())
    with pytest.raises(SnortError, match="[Oo]inkcode"):
        client.get_registered_rules(tmp_path)


def test_retry_then_success(snort_server, tmp_path):
    cfg = SnortConfig(
        community_url=f"{snort_server.base}/downloads/community/community-rules.tar.gz",
        reg_rules_base=f"{snort_server.base}/reg-rules",
        downloads_page=f"{snort_server.base}/downloads",
        retries=2,
        timeout=10,
    )
    snort_server.community_failures_left = 1
    client = SnortClient(cfg, requests.Session())
    p = client.get_community_rules(tmp_path)
    assert p.is_file()
    # было 2 запроса: 500 + 200
    community_reqs = [r for r in snort_server.requests if "community" in r]
    assert len(community_reqs) == 2


def test_cache_fallback_on_error(snort_server, tmp_path):
    cfg = SnortConfig(
        community_url=f"{snort_server.base}/downloads/community/community-rules.tar.gz",
        reg_rules_base=f"{snort_server.base}/reg-rules",
        downloads_page=f"{snort_server.base}/downloads",
        retries=0,
        use_cache_on_error=True,
        max_cache_age_days=7,
        timeout=10,
    )
    client = SnortClient(cfg, requests.Session())
    good = client.get_community_rules(tmp_path)
    # «вчерашний» кэш в архивах — должен использоваться при ошибке сети
    import datetime as dt

    yesterday_name = good.name.replace(
        dt.date.today().strftime("%Y%m%d"),
        (dt.date.today() - dt.timedelta(days=1)).strftime("%Y%m%d"),
    )
    yesterday = good.with_name(yesterday_name)
    yesterday.write_bytes(good.read_bytes())
    good.unlink()  # кэша за сегодня нет — сработает фолбэк
    snort_server.community_failures_left = 99
    cached = client.get_community_rules(tmp_path)
    assert cached == yesterday
