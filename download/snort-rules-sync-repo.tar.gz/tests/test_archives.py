"""Тесты распаковки архивов и выбора файлов правил."""

import pytest

from snort_rules_sync.archives import (
    ArchiveError,
    collect_rule_files,
    extract_tarball,
    read_text_safe,
)

from conftest import make_tar


def test_extract_and_collect(tmp_path):
    arch = make_tar(tmp_path / "a.tar.gz", {
        "rules/emerging-all.rules": "alert ip any any -> any any (msg:\"a\"; sid:1; rev:1;)\n",
        "rules/snort3-deleted.rules": "# deleted\n",
        "etc/snort.lua": "# not rules\n",
        "AUTHORS": "x\n",
    })
    dest = tmp_path / "out"
    extract_tarball(arch, dest)
    files = collect_rule_files(dest, ["**/*.rules"], ["snort3-deleted.rules", "*-deleted.rules"])
    names = [f.name for f in files]
    assert names == ["emerging-all.rules"]


def test_exclude_deletion_files(tmp_path):
    arch = make_tar(tmp_path / "b.tar.gz", {
        "rules/emerging-deleted.rules": "# del\n",
        "rules/decoder.rules": "# dec\n",
        "rules/preprocessor.rules": "# pre\n",
        "rules/real.rules": "alert ip any any -> any any (msg:\"r\"; sid:2; rev:1;)\n",
    })
    extract_tarball(arch, tmp_path / "out")
    files = collect_rule_files(
        tmp_path / "out", ["**/*.rules"],
        ["*-deleted.rules", "decoder.rules", "preprocessor.rules"],
    )
    assert [f.name for f in files] == ["real.rules"]


def test_path_traversal_rejected(tmp_path):
    # создаем архив со злонамеренным путём
    import tarfile, io

    bad = tmp_path / "bad.tar.gz"
    with tarfile.open(bad, "w:gz") as tar:
        data = b"alert ip any any -> any any (sid:1;)\n"
        info = tarfile.TarInfo("../../evil.rules")
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
    with pytest.raises(ArchiveError):
        extract_tarball(bad, tmp_path / "out")
    assert not (tmp_path / "evil.rules").exists()
    assert not (tmp_path.parent / "evil.rules").exists()


def test_symlink_skipped(tmp_path):
    import tarfile, io

    bad = tmp_path / "s.tar.gz"
    with tarfile.open(bad, "w:gz") as tar:
        data = b"alert ip any any -> any any (sid:1;)\n"
        info = tarfile.TarInfo("rules/real.rules")
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
        link = tarfile.TarInfo("rules/evil.rules")
        link.type = tarfile.SYMTYPE
        link.linkname = "/etc/passwd"
        tar.addfile(link)
    extract_tarball(bad, tmp_path / "out")
    files = collect_rule_files(tmp_path / "out", ["**/*.rules"], [])
    assert [f.name for f in files] == ["real.rules"]


def test_read_text_safe_latin(tmp_path):
    p = tmp_path / "r.rules"
    p.write_bytes(b'alert tcp any any -> any any (msg:"caf\xe9"; sid:1; rev:1;)\n')
    text = read_text_safe(p)
    assert "sid:1" in text


def test_glob_double_star(tmp_path):
    arch = make_tar(tmp_path / "c.tar.gz", {
        "a.rules": "x\n",
        "sub/b.rules": "x\n",
        "sub/deep/c.rules": "x\n",
        "d.list": "x\n",
    })
    extract_tarball(arch, tmp_path / "out")
    files = collect_rule_files(tmp_path / "out", ["**/*.rules"], [])
    assert sorted(f.name for f in files) == ["a.rules", "b.rules", "c.rules"]
